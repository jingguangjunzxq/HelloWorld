create view HT2_SYSTEMDEF as
select trim(code) sysid ,trim(name) sysname from cwbs.deptinfo1
/

