create view YBAPP_USERROLE as
  SELECT ui.unino userid,ui.name username,ri.rolecode roleid,ri.rolename rolename ,t.code proid ,t.name proname
               FROM yb_app_pro  t,cwbs.roleinfo ri ,cwbs.userrole ur ,cwbs.userinfo ui
                WHERE ur.unino = ui.unino AND ur.rolecode = ri.rolecode AND t.role = ur.rolecode
UNION
SELECT '01437' userid,'潘庚带' username,t.role roleid,t.name rolename ,t.code proid ,t.name proname
               FROM yb_app_pro  t
               UNION
SELECT '01438' userid,'AA1' username,t.role roleid,t.name rolename ,t.code proid ,t.name proname
               FROM yb_app_pro  t
               UNION
SELECT '01439' userid,'AA2' username,t.role roleid,t.name rolename ,t.code proid ,t.name proname
               FROM yb_app_pro  t
/

