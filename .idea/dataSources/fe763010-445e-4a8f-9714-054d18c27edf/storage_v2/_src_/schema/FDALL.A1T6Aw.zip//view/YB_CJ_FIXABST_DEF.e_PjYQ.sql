create view YB_CJ_FIXABST_DEF as
SELECT 
                          cast(ABST as char(50)) abst , 
                          cast(DEF as char(1)) def, 
                          cast(NETIN as char(1)) netin, 
                          cast('F' as char(1)) byMonthTd, 
                          cast('ZGCJ4' as char(30)) dbcode 
                    FROM ZGCJ4.fix_abst_ref a WHERE 1=1
/

