create function cb_calc_out_come_grp (
  v_node_no in CHAR,
  v_depart in CHAR
) Return number is result number;
v_groupid cb_outcome_grp.groupid%type;
v_act_ctl_val cb_outcome_ctl.act_ctl_val%type;
v_cnt number(1);
begin
  select count(*) into v_cnt from cb_outcome_grp where t_node=v_node_no;
  if(v_cnt = 0)then
    return 0;
  end if;
  --获取组号
  select groupid into v_groupid from cb_outcome_grp where t_node=v_node_no;
  --计算值
  select nvl(sum(coc.act_ctl_val), 0) act_ctl_val
    into v_act_ctl_val
    from cb_outcome_grp cog, cb_outcome_ctl coc, cb_parameters cp
    where cog.t_node=coc.t_node
    and cp.paramname='SYEAR'
    and coc.syear=cp.paramvalue
    and coc.depart=v_depart
    and groupid=v_groupid;

  return v_act_ctl_val;
End;


/

