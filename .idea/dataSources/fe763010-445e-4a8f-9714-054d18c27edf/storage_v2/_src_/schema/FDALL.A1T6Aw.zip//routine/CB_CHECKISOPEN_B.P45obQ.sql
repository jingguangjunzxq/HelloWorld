create function CB_CHECKISOPEN_b (
  v_depart in CHAR
) Return char is Result char(100);
Begin
  --请自行编辑函数体
 CB_CHECKISOPEN(v_depart);
End;
/

