create view YB4_PRJ_BUDGET as
Select   Cast(a.ky_prj_code As Char(32)) prj_code ,
                   Cast( a.t_code As Char(4) ) t_code ,
                   Cast( a.bu_code  As Char(20) ) bu_code ,
                   Cast( a.plan_amt As NUMBER(14,2) ) plan_amt,
                   Cast( a.freeze_amt As NUMBER(14,2))  freeze_amt,
                   Cast( a.exec_amt As NUMBER(14,2))  exec_amt
      From ky_zjyy_new.KYYB_budget a
/

