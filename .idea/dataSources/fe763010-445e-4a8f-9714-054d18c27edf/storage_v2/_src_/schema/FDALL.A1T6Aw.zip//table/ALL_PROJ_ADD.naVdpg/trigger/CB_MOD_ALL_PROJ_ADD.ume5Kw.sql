create trigger CB_MOD_ALL_PROJ_ADD
  before update
  on ALL_PROJ_ADD
  for each row
DECLARE

  V_LOG_ID NUMBER;


  V_MEMO VARCHAR2(2000);

BEGIN
  IF UPDATING THEN


    IF nvl(:OLD.COMM,'-1') != nvl(:NEW.COMM,'-1') THEN
    SELECT cb_checkclog.NEXTVAL into v_log_id FROM DUAL;
       V_MEMO := V_MEMO|| '审核意见由'||nvl(TRIM(:OLD.COMM),'空')||'改为'||nvl(TRIM(:NEW.COMM),'空');
        insert into cb_check_log
        (id, op_date, operator, memo,PROJ_CODE)
         values
        (v_log_id, sysdate , :NEW.COMM_OP, v_memo,:OLD.PROJ_CODE);
  END IF;
    END IF;
    IF nvl(:OLD.COMM2,'-1') != nvl(:NEW.COMM2,'-1') THEN
    SELECT cb_checkclog.NEXTVAL into v_log_id FROM DUAL;
       V_MEMO := '内部备注由'||nvl(TRIM(:OLD.COMM2),'空')||'改为'||nvl(TRIM(:NEW.COMM2),'空');
       insert into cb_check_log
        (id, op_date, operator, memo,PROJ_CODE)
         values
        (v_log_id, sysdate , :NEW.COMM_OP, v_memo,:OLD.PROJ_CODE);
    END IF;
    IF nvl(:OLD.REQ_AMT_CW,'-1') != nvl(:NEW.REQ_AMT_CW,'-1') THEN
    SELECT cb_checkclog.NEXTVAL into v_log_id FROM DUAL;
       V_MEMO :=  '批准申总请金额'||nvl(TRIM(:OLD.REQ_AMT_CW/10000),'空')||'改为'||TRIM(:NEW.REQ_AMT_CW/10000);
        insert into cb_check_log
        (id, op_date, operator, memo,PROJ_CODE)
         values
        (v_log_id, sysdate , :NEW.COMM_OP, v_memo,:OLD.PROJ_CODE);
    END IF;
    IF nvl(:OLD.ZC_AMT_CW,'-1') != nvl(:NEW.ZC_AMT_CW,'-1') THEN
    SELECT cb_checkclog.NEXTVAL into v_log_id FROM DUAL;
       V_MEMO :=  '批准自总筹金额'||nvl(TRIM(:OLD.ZC_AMT_CW/10000),'空')||'改为'||TRIM(:NEW.ZC_AMT_CW/10000);
       insert into cb_check_log
        (id, op_date, operator, memo,PROJ_CODE)
         values
        (v_log_id, sysdate , :NEW.COMM_OP, v_memo,:OLD.PROJ_CODE);
    END IF;





END CB_MOD_ALL_PROJ_ADD;


/

