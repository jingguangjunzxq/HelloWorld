create view CB_SR_EXEC as
select syear, i_node_no, sum(income) income
           from CB_INCOME_EXEC
          where smonth < 13
          group by syear, i_node_no


/

