create function cb_check_switch (
  v_switch_name in CHAR
) Return boolean is result boolean;
v_value cb_parameters.paramvalue%type;
begin
  execute immediate 'select paramvalue from cb_parameters ' ||
          'where paramname=upper(''' || v_switch_name || ''')'
    into v_value;
  if(trim(v_value) = 'T')then
    return true;
  else
    return false;
  end if;
End;


/

