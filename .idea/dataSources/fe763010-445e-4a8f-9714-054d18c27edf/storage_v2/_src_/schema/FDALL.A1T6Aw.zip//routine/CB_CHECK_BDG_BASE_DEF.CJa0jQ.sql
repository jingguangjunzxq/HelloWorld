create function cb_check_bdg_base_def (
  v_code in CHAR,
  v_chk_code in NUMBER,
  v_chk_father_code in NUMBER,
  syear in CHAR
) Return char is Result char(100);
v_syear char(4);
Begin
 --获取当前年份
 select trim(cp.paramvalue) into v_syear from cb_parameters cp where cp.paramname='SYEAR';
 if(syear <> v_syear)then
   return 'error:非当前年份数据不能修改';
 end if;
  --检查 v_code长度一定要是双数
 if mod(length(trim(v_code)),2)<>0 then
   return 'error:项目编码长度不正确';
 end if;
 --检查v_code是否已被占用
 if(v_chk_code>0)then
   return 'error:项目编码已被占用';
 end if;
 --检查上级代码是否存在
 if(length(trim(v_code))<>2)then--2位的不检查上级
   if(v_chk_father_code = 0)then
     return 'error:项目编码'||substr(v_code,1,length(trim(v_code))-2)||'不存在';
   end if;
 end if;
 return 'pass';
End;


/

