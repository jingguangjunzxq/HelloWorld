create function CB_CHECKISOPEN_a (
  V_PERSONID in CHAR
) Return char is Result char(100);
  V_TABLE          varchar2(60); /*表名*/
  V_PERSONID_CHECK VARCHAR2(10):= '部分';
  V_CJ_SJK_TYPE    VARCHAR2(5);
Begin
  --请自行编辑函数体
if (V_PERSONID_CHECK = '部分') then
    select trim(T.PARAMVALUE)
      into V_CJ_SJK_TYPE
      from YB_SYSPARAMS T
     where T.PARAMNAME = 'CJ_SJK_Type';
    if (V_CJ_SJK_TYPE = 'F')
    then
      /*老酬金库*/
      /* 得到表名*/
      select OWNER || '.' || TABLE_NAME
        into V_TABLE
        from (select *
                from ALL_TABLES
               where TABLE_NAME like 'GZ_MEMBER____'
                 and OWNER = V_DB
                 AND SUBSTR(TABLE_NAME,LENGTH(TABLE_NAME)-3)>=to_char(SYSDATE,'yyyy'))
       where ROWNUM = 1;
      V_SQL := 'SELECT COUNT(*) FROM ' || V_TABLE || '  t
               WHERE /*TRIM(t.CERCODE)= TRIM(''' || V_CERCODE || ''')
                     AND */ (upper(TRIM(t.PERSONID))=upper(TRIM(''' || V_PERSONID || '''))
                          or upper(TRIM(t.uni_key))=upper(TRIM(''' || V_PERSONID || '''))  )';       
    else
      V_TABLE := trim(V_DB) || '.MEMBERS';
      V_SQL := 'SELECT COUNT(*) FROM ' || V_TABLE || '  t
         WHERE /*TRIM(t.CERCODE)= TRIM(''' || V_CERCODE || ''')
               AND */ (upper(TRIM(t.PERSONID))=upper(TRIM(''' || V_PERSONID || '''))
                    or upper(TRIM(t.IDENTIFICATION))=upper(TRIM(''' || V_PERSONID || '''))  )';
    end if;
  else
    V_TABLE := 'yb_cj_gz_member_def';
    V_SQL := 'SELECT COUNT(*) FROM ' || V_TABLE || '  t
             WHERE /*TRIM(t.CERCODE)= TRIM(''' || V_CERCODE || ''')
                   AND */ (upper(TRIM(t.PERSONID))=upper(TRIM(''' || V_PERSONID || '''))
                        or upper(TRIM(t.uni_key))=upper(TRIM(''' || V_PERSONID || '''))  )';    
  end if;
End;
/

