create view YB_CJ_DNO as
select "DNO","DNAME" from ZGCJ4.Departs
/

