create view CB_INCOME_TREE_VIEW1 as
select a.node_no,a.name, a.p_node_no, '' last_node,'' mode_name,'' mode_type,
       nvl(civ.plan_val, 0) plan_val,
       a.syear,a.depart,a.table_name
  from (select distinct cit.itypea node_no,
                        x.sa_name name,
                        '' p_node_no,
                        '' last_node,
                        '' mode_name,
                        '' mode_type,
                        0 plan_val,
                        0 permit_val,
                        '' req_remark,
                        '' pmt_remark,
                        cbid.syear,
                        cbid.depart,
                        '' table_name
          from cb_income_type       cit,
               cb_budget_income_def cbid,
               xcodemap             x
         where cit.i_type = cbid.i_type
           and cit.itypea = x.sa_code
           and cit.apply_flag='Y'
           --and x.table_name='CB_INCOME_TYPE'
           and x.field_name='ITYPEA') a,cb_income_view1 civ
 where trim(a.node_no) = civ.i_node_no(+)
 and a.depart=civ.depart(+)
 and a.syear = civ.syear(+)


/

