create view CB_USERINFO as
select a.unino ,b.name ,b.password ,a.depart,a.departmaster from cb_user_apply a ,cwbs.userinfo b
where a.unino=b.unino(+)


/

