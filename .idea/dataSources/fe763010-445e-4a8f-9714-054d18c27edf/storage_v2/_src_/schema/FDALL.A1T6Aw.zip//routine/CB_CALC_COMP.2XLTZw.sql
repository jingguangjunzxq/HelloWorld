create function cb_calc_comp (
  v_comp in CHAR
) Return varchar2 is result varchar2(200);
v_value varchar2(200);
begin
  execute immediate 'select ''' || v_comp || ''' from dual'
    into v_value;
  return v_value;
End;


/

