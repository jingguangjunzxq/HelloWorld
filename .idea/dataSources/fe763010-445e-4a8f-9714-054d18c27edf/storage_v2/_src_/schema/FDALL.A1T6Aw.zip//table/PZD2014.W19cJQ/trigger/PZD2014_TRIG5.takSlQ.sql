create trigger PZD2014_TRIG5
  before insert or update of CLR_ORDER
  on PZD2014
  for each row
BEGIN

  IF (RTRIM(:NEW.CLR_ORDER) = '?') OR (RTRIM(:NEW.CLR_ORDER) = '？') THEN

    :NEW.CLR_ORDER := SUBSTR(:NEW.SYEAR || LPAD(:NEW.SMONTH, 2, '0'), 3) || ' ' || :NEW.STYPE2 || :NEW.SNO || '-' || :NEW.ORD;

  END IF;

END PZD2014_TRIG5;


/

