create view CB_OUTCOME_AP1 as
select cot.t_node,
       cot.t_name,
       cot.plan_depart,
       cot.add_allowed,
       cot.old_allowed,
       cot.ttypea,
       cot.ttypeb,
       xa.sa_name ta_name ,
       xb.sa_name tb_name,
       cot.depart,
       coc.depart depart_d,
       nvl(coc.fix_plan_b + coc.fix_plan_c,0) fix_val,
       nvl(coc.fix_plan_b,0) fix_plan_b,
       nvl(coc.fix_plan_c,0) fix_plan_c,
       prj.prj_code,
       prj.prj_name,
       prj.sa_depart depart_p,
       nvl(prj.apply_val,0) apply_val
  from xcodemap xa,
       xcodemap xb,
       (select * from CB_OUTCOME_TYPE ,cb_depart)  cot ,
       (select coc1.*
          from CB_OUTCOME_CTL coc1, cb_parameters cp1
         where cp1.paramvalue = coc1.syear
           and cp1.paramname = upper('syear')) coc,
       (select cot.t_node,
               cot.t_name,
               ap.prj_code,
               ap.name prj_name,
               ap.sa_depart,
               cocp.apply_val
          from CB_OUTCOME_TYPE cot,
               allproj ap,
               cb_parameters cp,
               (select cocp1.*
                  from CB_OUTCOME_CTL_PRJ cocp1, cb_parameters cp1
                 where cp1.paramvalue = cocp1.syear
                   and cp1.paramname = upper('syear')) cocp
         where cot.apply_flag = 'Y'
           and cot.t_node = ap.ys_attr
           and ap.ys_proj = 'Y'
           and (cot.old_allowed = 'Y' or cp.paramvalue = ap.start_year)
           and cp.paramname = upper('syear')
           and ap.prj_code = cocp.prj_code(+)) prj
 where xa.field_name = 'TTYPEA'
   and xa.sa_code = cot.ttypea
   and xb.field_name = 'TTYPEB'
   and xb.sa_code = cot.ttypeb
   and cot.apply_flag = 'Y'
   and cot.t_node = coc.t_node(+)
   and cot.depart=coc.depart(+)
   and cot.t_node = prj.t_node(+)
   and cot.depart=prj.sa_depart(+)
   and (cot.add_allowed = 'Y' or prj.sa_depart is not null )


/

