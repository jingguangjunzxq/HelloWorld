create view CB_CTL_VAL_VIEW1 as
select coc.syear, coc.depart, cot.ttypea, sum(coc.act_ctl_val) act_ctl_val_d
from cb_outcome_ctl coc, cb_outcome_type cot
where coc.t_node=cot.t_node
group by coc.syear, coc.depart, cot.ttypea


/

