create view YB4_BUDGET_STRUCTURE as
Select   Cast(a.BU_CODE As Char(20)) BU_CODE ,
                   Cast( a.BU_NAME As Char(80) ) BU_NAME ,
                   Cast( a.T_CODE  As Char(4) ) T_CODE ,
                   Cast( a.LEAF_FLAG As CHAR(1 ) ) LEAF_FLAG,
                   Cast( a.CTL_MODE As CHAR(1 ))  CTL_MODE,
                   Cast( a.MERGE_CODE As CHAR(1 ))  MERGE_CODE
      From ky_zjyy_new.BUDGET_STRUCTURE a
/

