create view SYS_USERINFO as
SELECT  userid,username ,password, modbdate
 FROM wf_tianyi.wf_userinfo
/

