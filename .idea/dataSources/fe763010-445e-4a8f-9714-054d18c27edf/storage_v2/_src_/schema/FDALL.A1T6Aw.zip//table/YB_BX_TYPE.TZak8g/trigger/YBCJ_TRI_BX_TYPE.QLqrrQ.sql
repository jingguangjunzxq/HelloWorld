create trigger YBCJ_TRI_BX_TYPE
  after update
  on YB_BX_TYPE
  for each row
DECLARE 
v_config_name VARCHAR2(30); 
v_sql VARCHAR2(3000); 
v_num NUMBER; 
jsonFlag CHAR(1) := 'T'; 
configFlag CHAR(1) := 'T'; 
v_bxord yb_bx_type.bx_ord%TYPE; 
v_validity yb_bx_type.validity%TYPE; 
v_old_validity yb_bx_type.validity%TYPE; 
BEGIN 
   v_bxord := :new.Bx_Ord; 
   v_validity := :new.Validity; 
   v_old_validity := :old.Validity; 
   --初始化修改标识 
   SELECT TRIM(t.paramvalue) INTO v_config_name FROM yb_sysparams t 
         where upper(trim(t.paramname)) = 'CONFIG_NAME' ; 
   BEGIN 
       v_sql :=  'select count(*)  from '||v_config_name||'.sys_query_detail '; 
        EXECUTE IMMEDIATE v_sql INTO v_num ; 
   EXCEPTION 
     WHEN OTHERS THEN 
       configFlag := 'F'; 
   END; 

   BEGIN 
       v_sql :=  'SELECT COUNT(*)  FROM wf_tianyi.wf_menu_node where business_id ='''||v_config_name||''' '; 
        EXECUTE IMMEDIATE v_sql INTO v_num ; 
        IF(v_num = 0)THEN 
             jsonFlag := 'F'; 
        end IF; 
   EXCEPTION 
     WHEN OTHERS THEN 
       jsonFlag := 'F'; 
   END; 
 --json 非json 版本修改体术业务。 
 /*修改特殊业务标识 
    从数据库查看表是否存在 
                  1287:冲销特殊暂借款 ; 
                    1288:合同冲暂存/质保金； 
                    1289：收入及分成预约 
                    1306 支付暂存/预收款 
                    1486 取号业务 
          1566 合同收款业务*/ 
 if(configFlag = 'T')THEN 

    IF(v_bxord ='8' AND v_validity='T' AND v_old_validity ='F')THEN 
        v_sql := 'insert into '||v_config_name||'.sys_role_menu(roleid,nodeid,isdefault)VALUES(''1'',''1287'',''N'')'; 
        EXECUTE IMMEDIATE v_sql; 
    ELSIF(v_bxord ='8' AND v_validity='F')THEN 
       v_sql := 'delete FROM '||v_config_name||'.sys_role_menu t  where t.nodeid =''1287'''; 
        EXECUTE IMMEDIATE v_sql; 
    ELSIF(v_bxord ='11' AND v_validity='T' AND v_old_validity ='F')THEN 
        v_sql := 'insert into '||v_config_name||'.sys_role_menu(roleid,nodeid,isdefault)VALUES(''1'',''1288'',''N'')'; 
        EXECUTE IMMEDIATE v_sql; 
    ELSIF(v_bxord ='11' AND v_validity='F')THEN 
       v_sql := 'delete FROM '||v_config_name||'.sys_role_menu t  where t.nodeid =''1288'''; 
        EXECUTE IMMEDIATE v_sql; 
    ELSIF(v_bxord ='12' AND v_validity='T' AND v_old_validity ='F')THEN 
        v_sql := 'insert into '||v_config_name||'.sys_role_menu(roleid,nodeid,isdefault)VALUES(''1'',''1289'',''N'')'; 
        EXECUTE IMMEDIATE v_sql; 
    ELSIF(v_bxord ='12' AND v_validity='F')THEN 
       v_sql := 'delete FROM '||v_config_name||'.sys_role_menu t  where t.nodeid =''1289'''; 
        EXECUTE IMMEDIATE v_sql; 
    ELSIF(v_bxord ='23' AND v_validity='T' AND v_old_validity ='F')THEN 
        v_sql := 'insert into '||v_config_name||'.sys_role_menu(roleid,nodeid,isdefault)VALUES(''1'',''1306'',''N'')'; 
        EXECUTE IMMEDIATE v_sql; 
    ELSIF(v_bxord ='23' AND v_validity='F')THEN 
       v_sql := 'delete FROM '||v_config_name||'.sys_role_menu t  where t.nodeid =''1306'''; 
        EXECUTE IMMEDIATE v_sql; 
    ELSIF(v_bxord ='26' AND v_validity='T' AND v_old_validity ='F')THEN 
        v_sql := 'insert into '||v_config_name||'.sys_role_menu(roleid,nodeid,isdefault)VALUES(''1'',''1486'',''N'')'; 
        EXECUTE IMMEDIATE v_sql; 
    ELSIF(v_bxord ='26' AND v_validity='F')THEN 
       v_sql := 'delete FROM '||v_config_name||'.sys_role_menu t  where t.nodeid =''1486'''; 
        EXECUTE IMMEDIATE v_sql; 
    ELSIF(v_bxord ='27' AND v_validity='T' AND v_old_validity ='F')THEN 
        v_sql := 'insert into '||v_config_name||'.sys_role_menu(roleid,nodeid,isdefault)VALUES(''1'',''1566'',''N'')'; 
        EXECUTE IMMEDIATE v_sql; 
    ELSIF(v_bxord ='26' AND v_validity='F')THEN 
       v_sql := 'delete FROM '||v_config_name||'.sys_role_menu t  where t.nodeid =''1566'''; 
        EXECUTE IMMEDIATE v_sql; 
    END IF; 
 END IF; 
 if(jsonFlag = 'T')THEN 
    IF(v_bxord ='8' AND v_validity='T' AND v_old_validity ='F')THEN 
        v_sql := 'insert into wf_tianyi.wf_role_menu(business_id,roleid,nodeid,isdefault) 
                     select t.business_id,''1'',t.nodeid,''N'' from WF_TIANYI.wf_menu_node t 
                        WHERE business_id = '''||v_config_name||''' AND t.sys_nodeid =''1287'' '; 
        EXECUTE IMMEDIATE v_sql; 
    ELSIF(v_bxord ='8' AND v_validity='F')THEN 
       v_sql := 'delete FROM wf_tianyi.wf_role_menu t  where  t.business_id = '''||v_config_name||''' 
                        and t.nodeid in (select a.nodeid from  WF_TIANYI.wf_menu_node a 
                            where a.business_id = '''||v_config_name||''' 
                                  AND a.sys_nodeid =''1287'') '; 
        EXECUTE IMMEDIATE v_sql; 
    ELSIF(v_bxord ='11' AND v_validity='T' AND v_old_validity ='F')THEN 
        v_sql := 'insert into wf_tianyi.wf_role_menu(business_id,roleid,nodeid,isdefault) 
                     select t.business_id,''1'',t.nodeid,''N'' from WF_TIANYI.wf_menu_node t 
                        WHERE business_id = '''||v_config_name||''' AND t.sys_nodeid =''1288'' '; 
        EXECUTE IMMEDIATE v_sql; 
    ELSIF(v_bxord ='11' AND v_validity='F')THEN 
       v_sql := 'delete FROM wf_tianyi.wf_role_menu t  where  t.business_id = '''||v_config_name||''' 
                        and t.nodeid in (select a.nodeid from  WF_TIANYI.wf_menu_node a 
                            where a.business_id = '''||v_config_name||''' 
                                  AND a.sys_nodeid =''1288'') '; 
        EXECUTE IMMEDIATE v_sql; 
    ELSIF(v_bxord ='12' AND v_validity='T' AND v_old_validity ='F')THEN 
        v_sql := 'insert into wf_tianyi.wf_role_menu(business_id,roleid,nodeid,isdefault) 
                     select t.business_id,''1'',t.nodeid,''N'' from WF_TIANYI.wf_menu_node t 
                        WHERE business_id = '''||v_config_name||''' AND t.sys_nodeid =''1289'' '; 
        EXECUTE IMMEDIATE v_sql; 
    ELSIF(v_bxord ='12' AND v_validity='F')THEN 
       v_sql := 'delete FROM wf_tianyi.wf_role_menu t  where  t.business_id = '''||v_config_name||''' 
                        and t.nodeid in (select a.nodeid from  WF_TIANYI.wf_menu_node a 
                            where a.business_id = '''||v_config_name||''' 
                                  AND a.sys_nodeid =''1289'') '; 
        EXECUTE IMMEDIATE v_sql; 
    ELSIF(v_bxord ='23' AND v_validity='T' AND v_old_validity ='F')THEN 
        v_sql := 'insert into wf_tianyi.wf_role_menu(business_id,roleid,nodeid,isdefault) 
                     select t.business_id,''1'',t.nodeid,''N'' from WF_TIANYI.wf_menu_node t 
                        WHERE business_id = '''||v_config_name||''' AND t.sys_nodeid =''1306'' '; 
        EXECUTE IMMEDIATE v_sql; 
    ELSIF(v_bxord ='23' AND v_validity='F')THEN 
       v_sql := 'delete FROM wf_tianyi.wf_role_menu t  where  t.business_id = '''||v_config_name||''' 
                        and t.nodeid in (select a.nodeid from  WF_TIANYI.wf_menu_node a 
                            where a.business_id = '''||v_config_name||''' 
                                  AND a.sys_nodeid =''1306'') '; 
        EXECUTE IMMEDIATE v_sql; 
    ELSIF(v_bxord ='26' AND v_validity='T' AND v_old_validity ='F')THEN 
        v_sql := 'insert into wf_tianyi.wf_role_menu(business_id,roleid,nodeid,isdefault) 
                     select t.business_id,''1'',t.nodeid,''N'' from WF_TIANYI.wf_menu_node t 
                        WHERE business_id = '''||v_config_name||''' AND t.sys_nodeid =''1486'' '; 
        EXECUTE IMMEDIATE v_sql; 
    ELSIF(v_bxord ='26' AND v_validity='F')THEN 
       v_sql := 'delete FROM wf_tianyi.wf_role_menu t  where  t.business_id = '''||v_config_name||''' 
                        and t.nodeid in (select a.nodeid from  WF_TIANYI.wf_menu_node a 
                            where a.business_id = '''||v_config_name||''' 
                                  AND a.sys_nodeid =''1486'') '; 
        EXECUTE IMMEDIATE v_sql; 
    ELSIF(v_bxord ='27' AND v_validity='T' AND v_old_validity ='F')THEN 
        v_sql := 'insert into wf_tianyi.wf_role_menu(business_id,roleid,nodeid,isdefault) 
                     select t.business_id,''1'',t.nodeid,''N'' from WF_TIANYI.wf_menu_node t 
                        WHERE business_id = '''||v_config_name||''' AND t.sys_nodeid =''1566'' '; 
        EXECUTE IMMEDIATE v_sql; 
    ELSIF(v_bxord ='27' AND v_validity='F')THEN 
       v_sql := 'delete FROM wf_tianyi.wf_role_menu t  where  t.business_id = '''||v_config_name||''' 
                        and t.nodeid in (select a.nodeid from  WF_TIANYI.wf_menu_node a 
                            where a.business_id = '''||v_config_name||''' 
                                  AND a.sys_nodeid =''1566'') '; 
        EXECUTE IMMEDIATE v_sql; 
    END IF; 
 END IF; 
END;
ALTER TRIGGER "YBCJ_TRI_BX_TYPE" ENABLE
/

