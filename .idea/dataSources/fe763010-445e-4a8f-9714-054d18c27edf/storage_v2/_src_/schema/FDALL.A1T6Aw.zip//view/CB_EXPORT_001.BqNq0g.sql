create view CB_EXPORT_001 as
select ap.prj_code, ap.ys_attr, ap.ys_proj, decode(trim(nvl(cot.plan_depart,'0080')),'0080',trim(ap.sa_depart),trim(cot.plan_depart)) sa_depart, cd.depart, cd.d_name, ap.name, ap.dep_remark , LYTAB.total_permit_val LYTAB_10, (SR2_F-SR248_F-SR249_F-SR234_F-SR239_F) DRVTAB_11, DRVTAB.SR1_F DRVTAB_12, (ZC_F+ZR2J_F+ZR3J_F+ZFK_F) DRVTAB_13, decode(trim(src_flag),'A',lytab.total_permit_val,0) LYTAB_20, decode(trim(src_flag),'A',(SR2_F-SR248_F-SR249_F-SR234_F-SR239_F),0) DRVTAB_23, decode(trim(src_flag),'A',(SR1_F),0) DRVTAB_22, decode(trim(src_flag),'A',(ZC_F+ZR2J_F+ZR3J_F+ZFK_F),0) DRVTAB_21, decode(trim(src_flag),'B',lytab.total_permit_val,0) LYTAB_30, decode(trim(src_flag),'B',(SR2_F-SR248_F-SR249_F-SR234_F-SR239_F),0) DRVTAB_31, decode(trim(src_flag),'B',(SR1_F),0) DRVTAB_32, decode(trim(src_flag),'B',(ZC_F+ZR2J_F+ZR3J_F+ZFK_F),0) DRVTAB_33
  from allproj ap,
       (select * from cb_outcome_ctl_prj where syear = '2013') CRTAB,
       (select * from cb_outcome_ctl_prj where syear = '2012') LYTAB,
       budget_drive.x_prjsum_y2 DRVTAB,
       CB_OUTCOME_TYPE cot,
       cb_depart cd
 where ap.prj_code = crtab.prj_code(+)
   and ap.prj_code = lytab.prj_code(+)
   and ap.prj_code = drvtab.code(+)
   and cd.depart = ap.sa_depart
   and cot.t_node = ap.ys_attr


/

