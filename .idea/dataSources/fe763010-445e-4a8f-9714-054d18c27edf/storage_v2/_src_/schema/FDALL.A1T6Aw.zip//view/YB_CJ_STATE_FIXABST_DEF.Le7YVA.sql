create view YB_CJ_STATE_FIXABST_DEF as
SELECT 
                             cast(d.code as number) code, 
                             cast(c.state_cw as char(40)) state_cw, 
                             cast(c.state_cj as char(50)) state, 
                             cast(a.fixabst as char(50)) fixabst, 
                             cast(upper(b.dbcode) as char(30) ) dbcode, 
                             cast('T' as char(1)) netin 
                        FROM 
                          yb_cj_member_fixabst_ref a, 
                          yb_cj_MEMBER_STATE_ref b, 
                          yb_cj_state_contrast_def c, 
                          yb_cj_state_def d 
                          WHERE a.state = b.STATE 
                          AND a.state = c.state_cj 
                          AND d.state_cw = c.state_cw
/

