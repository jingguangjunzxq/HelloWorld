create function CB_CHECKISOPEN2 (
  v_proj_code in CHAR,
  v_depart in CHAR
) Return char is Result char(100);
v_isopen number;
v_count number; 
v_sorta_grp char(20);
resultstr varchar2(100);
Begin

  resultstr:= cb_checkischeck_xj(v_depart);

  if resultstr <> 'pass' then
        return resultstr;
  end if;
  
 
 select sorta_grp into v_sorta_grp from all_proj_add a,cb_proj_sorta_cw b where proj_code = v_proj_code
 and a.sorta_cw = b.sorta;
 if v_sorta_grp not in (5,7,6)  and v_sorta_grp is not null then
    return'该项目审核，不能修改'; 
 end if;
  Return 'pass';
End;
/

