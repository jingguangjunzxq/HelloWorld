create view CB_APPLY_SECOND_ACTD as
select xp.sa_code node_no, cp.depart, sum(cp.act_ctl_val) act_ctl_val_d,
       sum(cp.act_ctl_val2) act_ctl_val_d2, sum(cp.act_ctl_val3) act_ctl_val_d3
  from cb_outcome_type ct,
       (select *
          from cb_outcome_ctl coc1, cb_parameters cp1
         where cp1.paramvalue = coc1.syear
           and cp1.paramname = upper('syear')) cp,
       cb_parameters cpt,
       cb_outcome_type_fathers cf,
       xcodemap xp
 where cpt.paramname = upper('syear')
   and ct.apply_flag = upper('y')
   and ct.t_node = cp.t_node
   and ct.t_node = cf.t_node
   and xp.field_name = upper('ttype')
   and cf.father_node = xp.sa_code
 group by xp.sa_code, cp.depart
 order by cp.depart, xp.sa_code


/

