create view CB_ADDPROJ_HOME as
select "NAME","REQ_OPERATOR","PLAN_YEAR","PLAN_AMT","STATUS","REQ_ORDER","MASTAR_ORDER","REQ_OP_NO","ORD",req_depart_no,proj_code,SORTA,master_depart_no
  from (select ps.sorta_name name,
               '' req_operator,
               0 plan_year,
               0 plan_amt,
               '' status,
               '' req_order,
               '' mastar_order,
               '' req_op_no,
               ps.sorta ord,'-1' req_depart_no,'' proj_code,PS.SORTA,ps.master_depart_no
          from CB_PROJ_SORTA ps
        union
        select '　　' || trim(ap.proj_code) || '　' || trim(ap.prj_name) name,
               trim(ap.req_operator) || '　(' || trim(ap.req_op_no) || ')' req_operator,
               ap.plan_year,
               round((ap.plan_amt) / 10000, 2) plan_amt,
               st.sa_name,
               ap.req_order,
               ap.master_order,
               ap.req_op_no,
               trim(ap.sorta) || trim(ap.proj_code) ord,ap.req_depart_no req_depart_no,ap.proj_code,AP.SORTA,''master_depart_no
          from all_proj_add ap,(select sa_code,trim(sa_name) sa_name from cb_codemap where field_name=upper('PRJ_STATUS')) st
          where ap.status=st.sa_code(+))
 order by ord


/

