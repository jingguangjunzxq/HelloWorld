create function cb_check_yb (
  v_proj_code in CHAR
) Return char is Result char(100);
v_status char(2);
Begin

  --请自行编辑函数体
  select nvl(status,0) into v_status from all_proj_add where proj_code = v_proj_code;
  if to_number(v_status)<10 then
     return '请先在网上填报后再申请预拨数';
  end if;
  Return 'pass';
End;


/

