create view CB_OUTCOME_PROJ_VIEW as
select a.prj_code node_no,
       a.name name,
       a.ys_attr p_node_no,
       'y' last_node,
       cot.mode_name,
       cpmd.mode_type,
       nvl(cocp.act_ctl_val, 0) act_ctl_val,
       a.start_year,
       a.sa_depart,
       cot.old_allowed,
       a.ys_attr,
       cezn.syear syear,
       cezn.depart depart,
       null act_ctl_val_d,
       null act_ctl_val_g,
       null add_allowed,
       cocp.fix_plan_a,
       cocp.fix_plan_b,
       cocp.fix_plan_c,
       apply_val,
       cot.apply_flag
  from cb_outcome_type       cot,
       cb_plan_mode_def     cpmd,
       cb_outcome_ctl_prj    cocp,
       CB_ENABLE_ZC_NODE     cezn,
       allproj               a
 where cot.t_node=cezn.t_node
 and cot.mode_name = cpmd.mode_name(+)
 and cot.t_node = a.ys_attr
 and a.prj_code = cocp.prj_code(+)
 and a.sa_depart = cezn.depart
 and a.ys_proj = 'Y'
 order by node_no


/

