create function cb_gen_req_remark (
  v_syear in CHAR,
  v_mode_name in CHAR,
  v_bu_code in CHAR,
  v_req_remark in CHAR,
  v_num_def in NUMBER,
  v_price_def in NUMBER
) Return char is result char;
v_remark varchar2(2000);
v_spec_def cb_pm_def_dtl.spec_def%type;
begin
  select cpdd.spec_def into v_spec_def from cb_pm_def_dtl  cpdd
    where cpdd.syear=v_syear
    and cpdd.mode_name=v_mode_name
    and cpdd.bu_code=v_bu_code;

    if(trim(v_spec_def) is null)then
      v_remark := v_req_remark;
    else
      v_remark := replace(replace(v_spec_def,'@数量@',v_num_def),'@标准@',v_price_def);
    end if;
    return v_remark;
End;


/

