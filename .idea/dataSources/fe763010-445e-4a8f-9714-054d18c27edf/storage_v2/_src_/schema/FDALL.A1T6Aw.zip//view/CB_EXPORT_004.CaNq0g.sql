create view CB_EXPORT_004 as
select ap.prj_code, ap.ys_attr, ap.ys_proj, decode(trim(nvl(cot.plan_depart,'0080')),'0080',trim(ap.sa_depart),trim(cot.plan_depart)) sa_depart, cd.depart, cd.d_name, ap.name, ap.dep_remark , decode(trim(src_flag),'A',(crtab.total_apply_val),0) CRTAB_24, decode(trim(src_flag),'A',lytab.total_permit_val,0) LYTAB_20, decode(trim(src_flag),'A',(SR2_G-SR248_G-SR249_G-SR234_G-SR239_G),0) DRVTAB_23, decode(trim(src_flag),'A',(ZC_G+ZR2J_G+ZR3J_G+ZFK_G),0) DRVTAB_21, decode(trim(src_flag),'B',(crtab.total_apply_val),0) CRTAB_34, decode(trim(src_flag),'B',lytab.total_permit_val,0) LYTAB_30, decode(trim(src_flag),'B',(SR1_G),0) DRVTAB_32, decode(trim(src_flag),'B',(ZC_G+ZR2J_G+ZR3J_G+ZFK_G),0) DRVTAB_33
  from allproj ap,
       (select * from cb_outcome_ctl_prj where syear = '2013') CRTAB,
       (select * from cb_outcome_ctl_prj where syear = '2012') LYTAB,
       budget_drive.x_prjsum_y2 DRVTAB,
       CB_OUTCOME_TYPE cot,
       cb_depart cd
 where ap.prj_code = crtab.prj_code(+)
   and ap.prj_code = lytab.prj_code(+)
   and ap.prj_code = drvtab.code(+)
   and cd.depart = ap.sa_depart
   and cot.t_node = ap.ys_attr


/

