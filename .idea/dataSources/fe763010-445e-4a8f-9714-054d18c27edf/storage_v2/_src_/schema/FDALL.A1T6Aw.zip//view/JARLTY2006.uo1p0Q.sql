create view JARLTY2006 as
select to_char(to_date(SYEAR || '/' || SMONTH || '/' || SDAY,'yyyy/mm/dd'),'yyyymmdd') as pzdate,J_AMOUNT,zph,SABSTRACT,SUBJ,D_AMOUNT,UNI_NO,STYPE from PZD2006


/

