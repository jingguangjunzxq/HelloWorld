create view T_RYJBXX as
SELECT "GH","XM","XB","DW","DW2","ZZBZ","XZZW","ZXZT","CSRQ","ZC","SFZH","RYLB","XSLB" FROM t_ryjbxx@CAMPUSCARD
/

