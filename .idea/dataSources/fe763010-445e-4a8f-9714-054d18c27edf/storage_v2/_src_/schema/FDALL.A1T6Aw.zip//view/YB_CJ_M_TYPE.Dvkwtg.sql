create view YB_CJ_M_TYPE as
select "M_TYPE","M_NAME","GZ" from ZGCJ4.member_type
/

