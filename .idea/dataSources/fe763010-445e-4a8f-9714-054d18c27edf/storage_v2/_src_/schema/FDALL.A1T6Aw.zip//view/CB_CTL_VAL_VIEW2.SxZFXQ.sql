create view CB_CTL_VAL_VIEW2 as
select coc.syear, coc.depart, cot.ttypeb, sum(coc.act_ctl_val) act_ctl_val_d
from cb_outcome_ctl coc, cb_outcome_type cot
where coc.t_node=cot.t_node
group by coc.syear, coc.depart, cot.ttypeb


/

