create function cb_checkischeck_xj(
  v_depart in CHAR
) Return char is Result char(100);
v_flag char(1);
Begin
  --请自行编辑函数体
  select trim(paramvalue) into v_flag from cb_parameters where trim(paramname) = 'ISOPENXJ';
  if v_flag = 'F' then
     return '系统已关闭'; 
  end if;
  Return 'pass';
End;
/

