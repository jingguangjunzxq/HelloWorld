create view YBAPP_ROLEINFO as
select rolecode rolecode,rolename rolename from cwbs.roleinfo
/

