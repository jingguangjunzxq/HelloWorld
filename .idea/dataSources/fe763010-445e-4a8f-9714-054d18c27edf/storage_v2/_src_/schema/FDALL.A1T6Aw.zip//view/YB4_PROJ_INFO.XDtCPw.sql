create view YB4_PROJ_INFO as
Select   Cast(a.ky_prj_code As Char(32)) prj_code ,
                   Cast( Substr(a.ky_prj_code,0, Decode( Instr(trim(a.ky_prj_code),'.'), 0 , Length(trim(a.ky_prj_code)), Instr(trim(a.ky_prj_code),'.')-1))  As Char(32) )   main_prj_code,
                   Cast( a.ky_prj_name As Char(200) ) prj_name ,
                   Cast( a.sno  As Char(20) ) prj_sno ,
                   Cast( a.sname As Char(50) ) prj_sname,
                   Cast( a.dno As Char(20))  prj_dno,
                   Cast( a.depart As Char(40))  prj_depart,
                   Cast( a.t_code As Char(4))  t_code,
                   Cast( Case When a.cw_prj_code Is Null Then 'N'  Else 'Y' End  As Char(1))  validity,
                   Cast( a.START_TIME As Char(10))  create_date,
                   Cast( a.end_time As Char(10))  finish_date
      From ky_zjyy_new.ky_prj_info a
/

