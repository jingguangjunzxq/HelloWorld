create trigger TRIG_AUTOADD_WFINST_HIST_ORD
  before insert
  on NEWWF_INSTANCE_HISTORY
  for each row
DECLARE
tmpVar NUMBER;
BEGIN
   tmpVar := 0;
   SELECT SEQ_NEWWF_INST_HISTORY_ORD.NEXTVAL INTO tmpVar FROM dual;
   :NEW.ORD := tmpVar;
END trig_autoadd_wfinst_hist_ord;

/

