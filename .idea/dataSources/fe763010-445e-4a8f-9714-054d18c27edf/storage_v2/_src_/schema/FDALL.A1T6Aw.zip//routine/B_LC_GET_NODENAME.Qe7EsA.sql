create function B_LC_GET_NODENAME (
  v_wf_name in CHAR,
  v_node_type in CHAR,
  v_node_name in CHAR
) Return char is Result char(100);
v_name newwf_act_def.act_name%type;
v_cnt number;
Begin
--初始默认为平台已设置的值
v_name:=  v_node_name;
--在节点名称为空的时候修改节点类型会影响节点名称，否则不影响
 if trim(v_node_name ) = '' or trim(v_node_name) is null then
  --请自行编辑函数体
  	  select act_name into v_name
	  from     newwf_act_def
	  where wf_name = v_wf_name
	  and act_id =    v_node_type ;
end if  ;

  Return v_name;
End;
/

