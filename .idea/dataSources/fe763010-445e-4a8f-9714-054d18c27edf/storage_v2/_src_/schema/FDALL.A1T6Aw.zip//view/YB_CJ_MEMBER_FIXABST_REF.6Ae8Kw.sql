create view YB_CJ_MEMBER_FIXABST_REF as
select 
                              cast(t.state as char(50)) state, 
                              cast(t.fixabst as char(50)) fixabst, 
                              cast(t.taxname as char(20)) taxname, 
                              cast(a.netin as char(20)) netin, 
                              cast('ZGCJ4' as char(30)) dbcode 
                          from ZGCJ4.member_fixabst_ref t, ZGCJ4.fix_abst_ref A 
                          where 1=1 AND a.abst(+)=t.fixabst
/

