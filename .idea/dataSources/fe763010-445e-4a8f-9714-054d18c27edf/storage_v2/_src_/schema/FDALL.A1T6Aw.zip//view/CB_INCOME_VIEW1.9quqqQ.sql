create view CB_INCOME_VIEW1 as
select a.syear, substr(a.i_node_no,1,1) i_node_no, sum(a.plan_val) plan_val, b.depart
from cb_budget_income a, cb_budget_income_def b
where a.syear=b.syear and a.i_node_no=b.i_node_no
group by a.syear, substr(a.i_node_no,1,1), b.depart


/

