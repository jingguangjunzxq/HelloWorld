create view YB_CJ_TNO as
select "TNO","TNAME","DNO" from ZGCJ4.Teams
/

