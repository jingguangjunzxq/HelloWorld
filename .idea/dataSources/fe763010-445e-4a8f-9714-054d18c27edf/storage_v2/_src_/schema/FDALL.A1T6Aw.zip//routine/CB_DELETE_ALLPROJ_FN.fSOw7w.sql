create function cb_delete_allproj_fn (
  v_node_no in CHAR
) Return char is result char;
v_start_year cb_parameters.paramvalue%type;
v_syear cb_parameters.paramvalue%type;
Begin
 if(substr(v_node_no,1,4) <> 'NEW1')then
   return '该项目不允许删除';
 end if;
 select cp.paramvalue into v_syear from cb_parameters cp where cp.paramname='SYEAR';

 delete from allproj where prj_code=v_node_no;
 delete from cb_outcome_apply_pm where syear = v_syear and prj_code = v_node_no;
 delete from cb_outcome_apply_pm_log where syear = v_syear and prj_code = v_node_no;
 delete from cb_outcome_ctl_prj where syear = v_syear and prj_code = v_node_no;
 delete from cb_outcome_ctl_prj_log where syear = v_syear and prj_code = v_node_no;
 delete from cb_outcome_reagn_prj_log where syear = v_syear and prj_code = v_node_no;

 return 'success: 删除成功.';
End;


/

