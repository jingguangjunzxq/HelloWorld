create trigger P_B_D2011_TRIG1
  after insert or delete
  on PRJ_BUDGET_DTL2011
  for each row
begin

  if inserting then

    ADD_PRJ_BUDGET2011(:NEW.PRJ_CODE,:NEW.ACTIVITY_NO,:NEW.BU_CODE,:NEW.PLAN_AMT,:NEW.EXEC_AMT,:NEW.RESERVE_AMT);

  else

    ADD_PRJ_BUDGET2011(:OLD.PRJ_CODE,:OLD.ACTIVITY_NO,:OLD.BU_CODE,-:OLD.PLAN_AMT,-:OLD.EXEC_AMT,-:OLD.RESERVE_AMT);

  end if;

end;


/

