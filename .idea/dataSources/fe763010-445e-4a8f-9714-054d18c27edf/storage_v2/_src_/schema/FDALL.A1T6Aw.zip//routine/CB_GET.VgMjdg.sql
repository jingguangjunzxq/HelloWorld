create function cb_get (
  v_start_date in DATE,
  v_end_date in DATE
) Return char is Result char(100);
Begin
  --请自行编辑函数体
  Return to_number(to_char(v_end_date,'yyyy'))-to_number(to_char(v_start_date,'yyyy'))+1;
End;


/

