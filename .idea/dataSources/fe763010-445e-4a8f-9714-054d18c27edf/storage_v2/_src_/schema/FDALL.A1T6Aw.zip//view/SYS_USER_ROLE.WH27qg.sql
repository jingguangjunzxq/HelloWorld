create view SYS_USER_ROLE as
select trim(t.userid) userid,t.roleid roleid FROM wf_tianyi.WF_PRJ_USER_ROLE t WHERE trim(t.project_id) ='WF2'
/

