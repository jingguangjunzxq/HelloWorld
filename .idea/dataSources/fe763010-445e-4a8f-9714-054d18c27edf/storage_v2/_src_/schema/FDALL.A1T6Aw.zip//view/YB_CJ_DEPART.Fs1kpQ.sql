create view YB_CJ_DEPART as
select "DNO","DNAME" from ZGCJ4.Departs
/

