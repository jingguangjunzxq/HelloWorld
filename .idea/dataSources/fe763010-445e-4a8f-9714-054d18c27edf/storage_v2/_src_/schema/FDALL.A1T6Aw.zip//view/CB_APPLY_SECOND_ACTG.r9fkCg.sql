create view CB_APPLY_SECOND_ACTG as
select node_no, depart, sum(act_ctl_val) act_ctl_val_g,
       sum(act_ctl_val2) act_ctl_val_g2, sum(act_ctl_val3) act_ctl_val_g3
  from (select distinct xp.sa_code node_no,
                        nvl(cg.groupid, 'vgrp' || trim(ct.t_node)) groupid
          from cb_outcome_type         ct,
               cb_outcome_type_fathers cf,
               xcodemap                xp,
               cb_outcome_grp          cg
         where ct.apply_flag = upper('y')
           and ct.t_node = cf.t_node
           and xp.field_name = upper('ttype')
           and cf.father_node = xp.sa_code
           and ct.t_node = cg.t_node(+)) t,
       (select groupid, depart, sum(act_ctl_val) act_ctl_val,
               sum(act_ctl_val2) act_ctl_val2, sum(act_ctl_val3) act_ctl_val3
          from (select distinct nvl(cg2.groupid, 'vgrp' || trim(ct.t_node)) groupid,
                                nvl(cg2.t_node, ct.t_node) t_node2
                  from cb_outcome_type ct,
                       cb_outcome_grp  cg,
                       cb_outcome_grp  cg2
                 where ct.apply_flag = upper('y')
                   and ct.t_node = cg.t_node(+)
                   and cg.groupid = cg2.groupid(+)) t,
               cb_outcome_type ct2,
               (select *
                  from cb_outcome_ctl coc1, cb_parameters cp1
                 where cp1.paramvalue = coc1.syear
                   and cp1.paramname = upper('syear')) cp
         where t.t_node2 = ct2.t_node
           and ct2.apply_flag = upper('y')
           and ct2.t_node = cp.t_node
         group by groupid, depart) tt
 where t.groupid = tt.groupid(+)
 group by node_no, depart
 order by node_no


/

