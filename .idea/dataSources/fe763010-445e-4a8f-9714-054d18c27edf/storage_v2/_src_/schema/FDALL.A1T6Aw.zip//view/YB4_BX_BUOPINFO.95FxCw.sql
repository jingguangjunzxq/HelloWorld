create view YB4_BX_BUOPINFO as
Select t.unino ,t.name From cwbs.userinfo t
/

