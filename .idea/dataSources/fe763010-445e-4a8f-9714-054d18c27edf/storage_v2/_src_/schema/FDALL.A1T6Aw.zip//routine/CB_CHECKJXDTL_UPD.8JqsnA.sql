create function cb_checkjxdtl_upd (
  v_updProj in char
) Return char is Result char(100);
Begin
  --请自行编辑函数体
  Return cb_checkjxdtl (v_updProj);
End;


/

