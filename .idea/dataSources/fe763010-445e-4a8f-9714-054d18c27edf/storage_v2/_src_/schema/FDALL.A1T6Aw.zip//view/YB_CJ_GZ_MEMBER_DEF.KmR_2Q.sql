create view YB_CJ_GZ_MEMBER_DEF as
select 
                              cast(no as char(21)) no, 
                              cast(personid as char(20)) personid, 
                              cast(uni_key as char(20)) uni_key, 
                              cast(name as char(100)) name, 
                              cast(dno as char(20)) dno, 
                              cast(depart as char(40)) depart, 
                              cast(tno as char(20)) tno, 
                              cast(team as char(50)) team, 
                              cast(card1 as char(50)) card1, 
                              cast(branchcode1 as char(12)) branchcode1, 
                              cast(card2 as char(50)) card2, 
                              cast(branchcode2 as char(12)) branchcode2, 
                              cast(card3 as char(50)) card3, 
                              cast(branchcode3 as char(12)) branchcode3, 
                              cast(card4 as char(50)) card4, 
                              cast(branchcode4 as char(12)) branchcode4, 
                              cast(card5 as char(50)) card5, 
                              cast(branchcode5 as char(12)) branchcode5, 
                              cast(card6 as char(50)) card6, 
                              cast(branchcode6 as char(12)) branchcode6, 
                              cast(card7 as char(50)) card7, 
                              cast(branchcode7 as char(12)) branchcode7, 
                              cast(notax as char(1)) notax, 
                              cast(emp as char(1)) emp, 
                              cast(state as char(50)) state, 
                              cast(tel as varchar2(40)) tel, 
                              cast(expiration as date) expiration, 
                              cast(csrq as date) csrq, 
                              cast(tech_post as char(20)) tech_post, 
                              cast(rank_post as char(40)) rank_post, 
                              cast(cercode as char（20)) cercode, 
                              '' BANKNO, 
                              cast(name as char(100)) other_unit, 
                              cast('ZGCJ4' as char(30)) dbcode, 
                              cast(sex as char(4)) sex, 
                              cast(huji as varchar2(40)) huji, 
                              cast(company AS varchar2(200)) company, 
                              cast(postcode as char(6)) postcode, 
                              cast(address as varchar2(80)) address ， 
                              cast(inputdate as date) inputdate  ， 
                              cast(inputuser as char(30)) inputuser， 
                              cast(remark as varchar2(200)) remark ， 
                              cast(procode as char(20)) procode ， 
                              cast(areacode as char(20)) areacode , 
                              cast(abstract as char(100)) abstract, 
                              cast(lhsj as char(20)) lhsj, 
                              cast(position as char(20)) position 
                            FROM ZGCJ4.gz_member2018 t
/

