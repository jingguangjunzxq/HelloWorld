create view HT2_ROLE as
select "ROLEID","ROLENAME","DES"from wf_htgl.sys_role t where t.roleid <> '3'
/

