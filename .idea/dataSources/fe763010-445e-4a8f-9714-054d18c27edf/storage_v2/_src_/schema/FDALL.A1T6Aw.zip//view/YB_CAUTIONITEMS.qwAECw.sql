create view YB_CAUTIONITEMS as
  SELECT t.paramvalue FROM yb_sysparams t WHERE trim(t.paramname)='cautionItems1'
UNION ALL
SELECT t.paramvalue FROM yb_sysparams t WHERE trim(t.paramname)='cautionItems2'
UNION ALL
SELECT t.paramvalue FROM yb_sysparams t WHERE trim(t.paramname)='cautionItems3'
UNION ALL
SELECT t.paramvalue FROM yb_sysparams t WHERE trim(t.paramname)='cautionItems4'
/

