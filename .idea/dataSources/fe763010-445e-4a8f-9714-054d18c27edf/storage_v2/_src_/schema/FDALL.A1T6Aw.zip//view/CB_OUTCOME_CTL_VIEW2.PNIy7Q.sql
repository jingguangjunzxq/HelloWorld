create view CB_OUTCOME_CTL_VIEW2 as
select coc.syear, substr(coc.t_node,1,2) t_node, coc.depart,
sum(coc.fix_plan_a) fix_plan_a,
sum(coc.fix_plan_b) fix_plan_b,
sum(coc.fix_plan_c) fix_plan_c
from cb_outcome_ctl coc
group by coc.syear, substr(coc.t_node,1,2), coc.depart


/

