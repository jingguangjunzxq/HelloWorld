create function cb_addproj_check (
  v_start_date in DATE,
  v_sorta_grp in CHAR,
  v_sorta in CHAR,
  v_prj_name in CHAR,
  v_prj_jx in CHAR,
  v_prj_bg in VARCHAR2,
  v_prj_act in CHAR,
  v_manager_no in CHAR,
  v_manager_name in CHAR,
  v_end_date in DATE,
  v_TEL in CHAR,
  v_t1 in CHAR,
  v_b1 in CHAR,
  v_a1 in CHAR
) Return char is Result char(100);
Begin
  --请自行编辑函数体
   return cb_proj_check(result,v_end_date,v_start_date,v_sorta_grp,v_sorta,v_prj_name,v_manager_no,v_manager_name,
   v_tel,v_t1,v_b1,v_a1,v_prj_bg,v_prj_jx,v_prj_act);


End;


/

