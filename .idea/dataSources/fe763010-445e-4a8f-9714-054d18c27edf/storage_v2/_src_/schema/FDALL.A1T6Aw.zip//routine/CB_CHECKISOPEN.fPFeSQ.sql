create function CB_CHECKISOPEN (
  v_depart in CHAR
) Return char is Result char(100);
v_isopen number;
v_count number; 
v_sorta_grp char(20);
Begin
  --请自行编辑函数体
  select count(*) into v_count from cb_departoprdef where depart = v_depart;
  if v_count >  0 then
      select isopen into v_isopen from cb_departoprdef where depart = v_depart;
      if v_isopen = 0 then
         return '功能已关闭，如要修改请联系财务处' ;
      end if;
  end if;

  Return 'pass';
End;
/

