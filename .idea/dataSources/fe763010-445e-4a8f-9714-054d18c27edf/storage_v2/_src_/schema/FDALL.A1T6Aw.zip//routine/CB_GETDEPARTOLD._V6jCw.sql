create function cb_getdepartold (
  v_sorta in CHAR,
  v_prj_code in CHAR,
  v_name in CHAR
) Return char is Result char(100);
v_depart char(10);
Begin
  --请自行编辑函数体
  select TRIM(sa_depart) into v_depart from allproj where prj_code = v_prj_code;
  return v_depart;
End;
/

