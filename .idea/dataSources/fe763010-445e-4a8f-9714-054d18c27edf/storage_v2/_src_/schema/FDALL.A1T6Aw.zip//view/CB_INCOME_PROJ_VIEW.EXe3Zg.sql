create view CB_INCOME_PROJ_VIEW as
select cbid.i_node_no node_no,
       cbid.inode_name name,
       cbid.i_type p_node_no,
       'y' last_node,
       cit.mode_name,
       cpmd.mode_type,
       nvl(cbi.plan_val, 0) plan_val,
       cbid.syear,
       cbid.depart
  from cb_income_type       cit,
       cb_budget_income_def cbid,
       cb_plan_mode_def     cpmd,
       cb_budget_income     cbi
 where cit.i_type = cbid.i_type
   and cit.mode_name = cpmd.mode_name(+)
   and cbid.i_node_no = cbi.i_node_no(+)
   and cbid.syear = cbi.syear(+)
   and cit.apply_flag='Y'
 order by node_no


/

