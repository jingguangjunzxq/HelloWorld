create trigger YBCJ_TRI_LS_MEMBERS_TMP
  after update
  on YB_CJ_LS_MEMBERS_TMP
  for each row
DECLARE 
    /*新数据*/ 
    ID       NUMBER; /*id*/ 
    NAME     YB_CJ_LS_MEMBERS_TMP.name%type; /*姓名*/ 
    SPELLING YB_CJ_LS_MEMBERS_TMP.SPELLING%type; /*姓名缩写 getspell(姓名)*/ 
    ADDRESS  YB_CJ_LS_MEMBERS_TMP.ADDRESS%type; /*地址*/ 
    POSTCODE YB_CJ_LS_MEMBERS_TMP.POSTCODE%type; /*邮政编码*/ 
    HUJI     YB_CJ_LS_MEMBERS_TMP.HUJI%type; /*户籍所在地*/ 
    TEL      YB_CJ_LS_MEMBERS_TMP.TEL%type; /*联系电话*/ 
    SEX      YB_CJ_LS_MEMBERS_TMP.SEX%type; /*性别   男  女*/ 
    AREACODE yb_cj_ls_members_tmp.AREACODE%type; /*国家地区代码 countryarea*/ 
    NOTAX    YB_CJ_LS_MEMBERS_TMP.NOTAX%type; /*是否免税*/ 
    DNO      YB_CJ_LS_MEMBERS_TMP.DNO%TYPE; /*部门编号 DEPARTS  录入人姓名*/ 
    DEPART   YB_CJ_LS_MEMBERS_TMP.DEPART%TYPE; /*部门名称 录入人姓名*/ 
    TNO      YB_CJ_LS_MEMBERS_TMP.TNO%TYPE; /*班级编号  TEAMS*/ 
    TEAM     YB_CJ_LS_MEMBERS_TMP.TEAM%TYPE; /*班组名称*/ 
    CERCODE  YB_CJ_LS_MEMBERS_TMP.CERCODE%type; /*证件类型   certificate */ 
    PERSONID YB_CJ_LS_MEMBERS_TMP.PERSONID%type; /*证件号码*/ 
    --personid_file  char(100) ;/*上传*/ 
    EMP        YB_CJ_LS_MEMBERS_TMP.EMP%type; /* T 校内  F  校外*/ 
    MTYPE      YB_CJ_LS_MEMBERS_TMP.MTYPE%type; /*人员库类别  '  校外人员  账套 cj_user*/ 
    STATE      YB_CJ_LS_MEMBERS_TMP.state%type; /*人员性质  MEMBER_STATE_REF */ 
    OTHER_UNIT YB_CJ_LS_MEMBERS_TMP.OTHER_UNIT%type; /*银行账帐户名称  转卡人姓名   汇款单位*/ 
    cardNo     YB_CJ_LS_MEMBERS_TMP.cardNo%type;/*卡类型*/ 
    ACNT       YB_CJ_LS_MEMBERS_TMP.ACNT%type; /*银行账号*/ 
    BANKNO     YB_CJ_LS_MEMBERS_TMP.BANKNO%type; /*开户行*/ 
    BRANCHCODE YB_CJ_LS_MEMBERS_TMP.BRANCHCODE%type; /*联行号 财务库 branchinfo */ 
    --bank_file   char(100);/*银行卡*/ 
    INPUTUSER    YB_CJ_LS_MEMBERS_TMP.INPUTUSER%type; /*录入人姓名 */ 
    INPUTUSERNAME YB_CJ_LS_MEMBERS_TMP.INPUTUSERNAME%type; /*录入姓名*/ 
    INPUTDATE     DATE; /*录入时间*/ 
    --confirmuser char(40);/*审核人id*/ 
    STATUS YB_CJ_LS_MEMBERS_TMP.STATUS%type; /*状态  状态对照表  yb_cj_lsmem_status 10;申请;20 提交;25 退回，29 修改卡号;30 通过.*/ 
    --msg varchar2(500); /*批示*/ 
    DEL CHAR(1) DEFAULT 'F'; 
    BIRTHDAY    YB_CJ_LS_MEMBERS_TMP.BIRTHDAY%type; 
    lhsj        yb_cj_ls_members_tmp.lhsj%TYPE; 
    /*老数据*/ 
    V_STATUS      CHAR(2); 
    V_ID          NUMBER; /*id*/ 
    V_CERCODE     YB_CJ_LS_MEMBERS_TMP.CERCODE%type; /*证件类型   certificate */ 
    V_PERSONID    YB_CJ_LS_MEMBERS_TMP.PERSONID%type; /*证件号码*/ 
    V_OTHER_UNIT  YB_CJ_LS_MEMBERS_TMP.OTHER_UNIT%type; /*银行账帐户名称  转卡人姓名   汇款单位*/ 
    V_ACNT        YB_CJ_LS_MEMBERS_TMP.ACNT%type; /*银行账号*/ 
    V_BRANCHCODE  YB_CJ_LS_MEMBERS_TMP.BRANCHCODE%type; /*联行号 财务库 branchinfo */ 
    V_DEL         CHAR(1); 
    V_DB          VARCHAR2(30); 
    V_TABLE       VARCHAR2(60); /*表名*/ 
    V_SQL         VARCHAR2(2000); 
    V_NUM         NUMBER; 
    V_CJ_SJK_TYPE CHAR(1); /*酬金库是不是合并库*/ 
    AREACODE_NO   VARCHAR2(100); 
    V_M_TYPE_HB   CHAR(2); 
    V_MORD        NUMBER; 
    V_BIRTHDAY    CHAR(10); 
    v_defaultCardNo NUMBER := 1;/*插入的卡几标识*/ 

    --pragma autonomous_transaction; -- 指定自定义事务处理，否则不能在触发器函数中操作本表 
BEGIN 
   SELECT UPPER(TRIM(PARAMVALUE)) INTO V_DB 
         FROM YB_SYSPARAMS T 
         WHERE T.PARAMNAME = 'CJ_LS_DEF'; 
   SELECT TRIM(T.PARAMVALUE) 
        INTO V_CJ_SJK_TYPE 
        FROM YB_SYSPARAMS T 
        WHERE T.PARAMNAME = 'CJ_SJK_Type'; 
    IF (V_CJ_SJK_TYPE = 'F') THEN 
          /*老酬金库*/ 
          /* 得到表名*/ 
          SELECT OWNER || '.' || TABLE_NAME 
                  INTO V_TABLE 
                  FROM (SELECT * 
                          FROM ALL_TABLES 
                          WHERE TABLE_NAME LIKE 'GZ_MEMBER____' 
                          AND OWNER = V_DB 
                          ORDER BY TABLE_NAME DESC) 
                  WHERE ROWNUM = 1; 
          STATUS   := :NEW.STATUS; 
          DEL      := :NEW.DEL; 
          V_STATUS := :OLD.STATUS; 
          V_DEL    := :OLD.DEL; 
          /*新进人员：状态变成30，del = F*/ 
          /*删除: del = 'T'*/ 
          IF (DEL = 'T' AND V_DEL <> 'T') THEN 
                CERCODE  := :OLD.CERCODE; 
                PERSONID := :OLD.PERSONID; 
                V_SQL    := 'DELETE FROM ' || V_TABLE || ' WHERE TRIM(no) = trim(''' || PERSONID || ''')'; 
                EXECUTE IMMEDIATE V_SQL; 
          END IF; 
          /*IF(status = '29' AND del = 'F' AND  v_status='30' AND v_del = 'F')THEN 
          cercode  :=  :old.Cercode; 
          personid :=  :old.Personid; 
          v_sql := 'DELETE FROM '||v_table||' WHERE TRIM(no) = trim('''||personid||''')'; 
          EXECUTE IMMEDIATE v_sql ; 
          END IF;*/ 
          IF (STATUS = 30 AND DEL = 'F' AND(( v_status <> 30 AND v_status <>29)  OR TRIM(v_status) IS NULL )) THEN 
                /*新进人员*/ 
                ID            := :OLD.ID; 
                NAME          := :OLD.NAME; 
                SPELLING      := :OLD.SPELLING; 
                ADDRESS       := :OLD.ADDRESS; 
                POSTCODE      := :OLD.POSTCODE; 
                HUJI          := :OLD.HUJI; 
                TEL           := :OLD.TEL; 
                AREACODE      := :OLD.AREACODE; 
                NOTAX         := :OLD.NOTAX; 
                DNO           := :OLD.DNO; 
                DEPART        := :OLD.DEPART; 
                TNO           := :OLD.TNO; 
                TEAM          := :OLD.TEAM; 
                CERCODE       := :OLD.CERCODE; 
                PERSONID      := :OLD.PERSONID; 
                EMP           := :OLD.EMP; 
                STATE         := :OLD.STATE; 
                OTHER_UNIT    := :OLD.OTHER_UNIT; 
                ACNT          := :OLD.ACNT; 
                BANKNO        := :OLD.BANKNO; 
                SEX           := :OLD.SEX; 
                INPUTUSER     := :OLD.INPUTUSER; 
                BRANCHCODE    := :OLD.BRANCHCODE; 
                INPUTUSERNAME := :OLD.INPUTUSERNAME; 
                INPUTDATE     := :OLD.INPUTDATE; 
                MTYPE         := :OLD.MTYPE; 
                cardNo        := :OLD.CARDNO; 
                BIRTHDAY      := to_char(:OLD.Birthday,'yyyy-mm-dd'); 
                lhsj        :=  :OLD.lhsj; 
                /*修改卡号*/ 
                IF (STATUS = 30 AND V_STATUS = 29 
                AND :NEW.OTHER_UNIT IS NOT NULL 
                AND :NEW.ACNT IS NOT NULL) THEN 
                      OTHER_UNIT := :NEW.OTHER_UNIT; 
                      ACNT       := :NEW.ACNT; 
                      BRANCHCODE := :NEW.BRANCHCODE; 
                      cardNo     := :NEW.CARDNO; 
                END IF; 
                /*数据插入*/ 
                /*company := '帐户'  card7 := acnt*/ 
                V_SQL := 'SELECT COUNT(*) FROM ' || V_TABLE || 
                          ' t WHERE trim(t.no) = ''' || TRIM(PERSONID) || ''''; 
                EXECUTE IMMEDIATE V_SQL 
                                  INTO V_NUM; 
                IF (V_NUM <> 0) THEN 
                    V_SQL := 'DELETE FROM ' || V_TABLE || ' t WHERE t.no = ''' || TRIM(PERSONID) || ''''; 
                    EXECUTE IMMEDIATE V_SQL; 
                END IF; 
                V_SQL := ' SELECT COUNT(*) FROM yb_cj_countryarea_def t 
                          WHERE trim(t.AREANAME)=TRIM(''' || AREACODE || ''')'; 
                EXECUTE IMMEDIATE V_SQL INTO V_NUM; 
                IF (V_NUM > 0) THEN 
                        V_SQL := 'SELECT trim(t.AREACODE)  FROM yb_cj_countryarea_def t 
                        WHERE trim(t.AREANAME)=TRIM(''' || AREACODE || ''')'; 
                        EXECUTE IMMEDIATE V_SQL 
                        INTO AREACODE_NO; 
                END IF; 
                IF(cardNo<>'0')THEN 
                        V_SQL := ' 
                        INSERT INTO ' || V_TABLE || ' 
                        (no,ABSTRACT,name,DNO,DEPART, 
                        TNO,TEAM,NOTAX,EMP,PERSONID, 
                        UNI_KEY,STATE,AREACODE,CERCODE,INPUTUSER, 
                        INPUTDATE,ADDRESS,POSTCODE,HUJI,TEL, 
                        COMPANY,SEX,CARD'||cardNo||',BRANCHCODE'||cardNo||',CSRQ,remark, 
                        lhsj 
                        )VALUES 
                        (:1,:2,:3,:4,:5,:6,:7,:8,:9,:10,:11,:12,:13,:14,:15,:16,:17, 
                        :18,:19,:20,:21,:22,:23,:24,:25,''网上预约新增'',:26)'; 
                        EXECUTE IMMEDIATE V_SQL 
                        USING PERSONID, SUBSTR(TRIM(SPELLING), 0, 10), TRIM(NAME), trim(DNO), 
                        trim(DEPART), trim(TNO), trim(TEAM), CASE WHEN NOTAX LIKE '免%' THEN 'T' ELSE 'F' END, 
                         EMP, PERSONID, PERSONID, STATE, AREACODE_NO, CERCODE, INPUTUSER, INPUTDATE, ADDRESS, 
                         POSTCODE, HUJI, TEL, OTHER_UNIT, SEX, TRIM(ACNT), BRANCHCODE, 
                         to_date(BIRTHDAY,'yyyy-mm-dd'),to_date(lhsj,'yyyy-mm-dd'); 
                ELSE 
                        V_SQL := ' 
                        INSERT INTO ' || V_TABLE || ' 
                        (no,ABSTRACT,name,DNO,DEPART, 
                        TNO,TEAM,NOTAX,EMP,PERSONID, 
                        UNI_KEY,STATE,AREACODE,CERCODE,INPUTUSER, 
                        INPUTDATE,ADDRESS,POSTCODE,HUJI,TEL, 
                        COMPANY,SEX,CSRQ,remark,lhsj 
                        )VALUES 
                        (:1,:2,:3,:4,:5,:6,:7,:8,:9,:10,:11,:12,:13,:14,:15,:16,:17, 
                        :18,:19,:20,:21,:22,:23,''网上预约新增'',:24)'; 
                        EXECUTE IMMEDIATE V_SQL 
                        USING PERSONID, SUBSTR(TRIM(SPELLING), 0, 10), TRIM(NAME), trim(DNO), trim(DEPART), 
                        trim(TNO), trim(TEAM), CASE WHEN NOTAX LIKE '免%' THEN 'T' ELSE 'F' END, 
                        EMP, PERSONID, PERSONID, STATE, AREACODE_NO, CERCODE, INPUTUSER, INPUTDATE, 
                        ADDRESS, POSTCODE, HUJI, TEL, '', SEX,to_date(BIRTHDAY,'yyyy-mm-dd'), 
                        to_date(lhsj,'yyyy-mm-dd'); 
                END IF; 
          END IF; 
          /*老酬金库*/ 
    ELSE 
            STATUS   := :NEW.STATUS; 
            DEL      := :NEW.DEL; 
            V_STATUS := :OLD.STATUS; 
            V_DEL    := :OLD.DEL; 
            /*新进人员：状态变成30，del = F*/ 
            /*删除: del = 'T'*/ 
            IF (DEL = 'T' AND V_DEL <> 'T') THEN 
                  CERCODE  := :OLD.CERCODE; 
                  PERSONID := :OLD.PERSONID; 
                  V_SQL    := 'DELETE FROM ' || V_TABLE || ' WHERE TRIM(no) = trim(''' || 
                  PERSONID || ''')'; 
                  EXECUTE IMMEDIATE V_SQL; 
            END IF; 
            IF (STATUS = 30 AND DEL = 'F'  AND(( v_status <> 30 AND v_status <>29)  OR TRIM(v_status) IS NULL )) THEN 
                    /*新进人员*/ 
                    ID            := :OLD.ID; 
                    NAME          := :OLD.NAME; 
                    SPELLING      := :OLD.SPELLING; 
                    ADDRESS       := :OLD.ADDRESS; 
                    POSTCODE      := :OLD.POSTCODE; 
                    HUJI          := :OLD.HUJI; 
                    TEL           := :OLD.TEL; 
                    AREACODE      := :OLD.AREACODE; 
                    NOTAX         := :OLD.NOTAX; 
                    DNO           := :OLD.DNO; 
                    DEPART        := :OLD.DEPART; 
                    TNO           := :OLD.TNO; 
                    TEAM          := :OLD.TEAM; 
                    CERCODE       := :OLD.CERCODE; 
                    PERSONID      := :OLD.PERSONID; 
                    EMP           := :OLD.EMP; 
                    STATE         := :OLD.STATE; 
                    OTHER_UNIT    := :OLD.OTHER_UNIT; 
                    ACNT          := :OLD.ACNT; 
                    BANKNO        := :OLD.BANKNO; 
                    SEX           := :OLD.SEX; 
                    INPUTUSER     := :OLD.INPUTUSER; 
                    BRANCHCODE    := :OLD.BRANCHCODE; 
                    INPUTUSERNAME := :OLD.INPUTUSERNAME; 
                    INPUTDATE     := :OLD.INPUTDATE; 
                    MTYPE         := :OLD.MTYPE; 
                    cardNo        := :OLD.CARDNO; 
                    lhsj          := :OLD.lhsj; 
                    /*修改卡号*/ 
                    IF (STATUS = 30 AND V_STATUS = 29 
                    AND :NEW.OTHER_UNIT IS NOT NULL AND :NEW.ACNT IS NOT NULL) THEN 
                        OTHER_UNIT := :NEW.OTHER_UNIT; 
                        ACNT       := :NEW.ACNT; 
                        BRANCHCODE := :NEW.BRANCHCODE; 
                        BANKNO     := :NEW.BANKNO; 
                        cardNo     := :NEW.CARDNO; 
                    END IF; 
                    /*数据插入*/ 
                    /*company := '帐户'  card7 := acnt*/ 
                    V_SQL := 'SELECT COUNT(*) FROM ' || V_DB || 
                    '.MEMBERS t WHERE trim(t.uni_no) = ''' || TRIM(PERSONID) || ''''; 
                    EXECUTE IMMEDIATE V_SQL INTO V_NUM; 
                    IF (V_NUM <> 0) THEN 
                        V_SQL := 'DELETE FROM ' || V_DB || '.MEMBERS t WHERE t.uni_no = ''' || 
                        TRIM(PERSONID) || ''''; 
                        EXECUTE IMMEDIATE V_SQL; 
                    END IF; 
                    V_SQL := 'SELECT COUNT(*) FROM yb_cj_countryarea_def t 
                          WHERE trim(t.AREANAME)=TRIM(''' || AREACODE || ''')'; 
                    EXECUTE IMMEDIATE V_SQL INTO V_NUM; 
                    IF (V_NUM > 0) THEN 
                          V_SQL := 'SELECT trim(t.AREACODE)  FROM yb_cj_countryarea_def t 
                          WHERE trim(t.AREANAME)=TRIM(''' || AREACODE || ''')'; 
                          EXECUTE IMMEDIATE V_SQL 
                          INTO AREACODE_NO; 
                    END IF; 
                    --如果   卡类型小于7则按卡类型保存数据 
                    IF(cardNo <=7 AND cardNo >0)THEN 
                          v_defaultCardNo :=  cardNo; 
                    END IF; 
                    V_SQL := 'select max(trim(t.m_type)) 
                    from ' || V_DB || '.M_TYPE_STATE_REF t WHERE 
                    trim(t.state)= trim(''' || STATE || ''')'; 
                    EXECUTE IMMEDIATE V_SQL 
                    INTO V_M_TYPE_HB; 
                    V_SQL := 'select nvl(max(t.MORD),''0'')+1 
                    from ' || V_DB || '.MEMBERS t '; 
                    EXECUTE IMMEDIATE V_SQL 
                    INTO V_MORD; 
                    V_SQL := 'INSERT INTO ' || V_DB || '.MEMBERS 
                    (UNI_NO,SPELLING,name,DNO2,DEPART2, 
                    TNO2,TEAM2,NOTAX,EMP,PERSONID, 
                    IDENTIFICATION,STATE,AREACODE,CERCODE,INPUTUSER, 
                    INPUTDATE,ADDRESS,POSTCODE,HUJI,TELE2, 
                    SEX,M_TYPE,dno_ss,depart_ss,MORD,card1,CARDNAME1,CARDBANK1,branchcode1,remark, 
                    lhsj,TELE 
                    )VALUES 
                    (:1,:2,:3,:4,:5,:6,:7,:8,:9,:10,:11,:12,:13,:14,:15,:16,:17, 
                    :18,:19,:20,:21,:22,:23,:24,:25,:26,:27,:28,:29,''网上预约新增'',:30,:31)'; 
                    EXECUTE IMMEDIATE V_SQL 
                    USING PERSONID, SUBSTR(TRIM(SPELLING), 0, 10), TRIM(NAME), 
                    trim(DNO), trim(DEPART), trim(TNO), trim(TEAM), 
                    CASE WHEN NOTAX LIKE '免%' THEN 'T' ELSE 'F' END, EMP, PERSONID, PERSONID, 
                    STATE, AREACODE_NO, CERCODE, INPUTUSER, INPUTDATE, ADDRESS, POSTCODE, HUJI, TEL, SEX, 
                    V_M_TYPE_HB,  trim(TNO), trim(TEAM), V_MORD,TRIM(ACNT), OTHER_UNIT,lpad(trim(cardNo),2,'0'), 
                    BRANCHCODE,to_date(lhsj,'yyyy-mm-dd'),TEL; 
            END IF; 
END IF; 
-- COMMIT; 
END ROLEUPDATE;
/

