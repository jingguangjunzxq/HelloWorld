create view CB_DEPART as
select sa_code depart,sa_name d_name,trim(f1_name)||nvl2(f2_name,'／'||trim(f2_name),null)||nvl2(f3_name,'／'||trim(f3_name),null)||nvl2(f4_name,'／'||trim(f4_name),null)||nvl2(f5_name,'／'||trim(f5_name),null) pathname,
  f1_code departa,f1_name departa_name,f2_code departb ,f2_name departb_name,f3_code departc,f3_name departc_name,f4_code departd,f4_name departd_name
  from (
  select a.*,
    decode(childnum, 0, 'E', 1, 'T', 'F') leaf,
    (select sa_name from xcodemap B where B.field_name = A.field_name and B.sa_code = A.f1_code) f1_name,
    (select sa_name from xcodemap B where B.field_name = A.field_name and B.sa_code = A.f2_code) f2_name,
    (select sa_name from xcodemap B where B.field_name = A.field_name and B.sa_code = A.f3_code) f3_name,
    (select sa_name from xcodemap B where B.field_name = A.field_name and B.sa_code = A.f4_code) f4_name,
    (select sa_name from xcodemap B where B.field_name = A.field_name and B.sa_code = A.f5_code) f5_name
  from
  (
  select A.*, 1 lev, (select count(*) from xcodemap B where B.field_name = A.field_name and B.f1_code = A.f1_code) childnum from xcodemap A where field_name = 'SA_DEPART' and sa_code = f1_code and f2_code is null
  union all
  select A.*, 2 lev, (select count(*) from xcodemap B where B.field_name = A.field_name and B.f2_code = A.f2_code) childnum from xcodemap A where field_name = 'SA_DEPART' and sa_code = f2_code and f3_code is null
  union all
  select A.*, 3 lev, (select count(*) from xcodemap B where B.field_name = A.field_name and B.f3_code = A.f3_code) childnum from xcodemap A where field_name = 'SA_DEPART' and sa_code = f3_code and f4_code is null
  union all
  select A.*, 4 lev, (select count(*) from xcodemap B where B.field_name = A.field_name and B.f4_code = A.f4_code) childnum from xcodemap A where field_name = 'SA_DEPART' and sa_code = f4_code and f5_code is null
  ) A where childnum=1
  )


/

