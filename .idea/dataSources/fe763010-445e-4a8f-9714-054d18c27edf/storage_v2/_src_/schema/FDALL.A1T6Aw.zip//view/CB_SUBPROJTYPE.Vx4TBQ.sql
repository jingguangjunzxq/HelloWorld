create view CB_SUBPROJTYPE as
select  DISTINCT lpad('　',(length(trim(d.sort_id))-2)*2,'　')||d.sort_name name,d.sort_id,b.master_depart_no
  from CB_PROJ_SORTID a, CB_PROJ_SORTA b, CB_PROJ_SORTID_FATHERS c,CB_PROJ_SORTID d
 where a.leaf = 'Y'
   and a.sorta = b.sorta
   and a.sort_id=c.sort_id
   and c.father_id=d.sort_id


/

