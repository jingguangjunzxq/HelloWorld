create view YB_CJ_CARDDEF as
select cast(BANKNO as number(2)) bankno, 
                                     cast(NAME as char(20)) name, 
                                     cast(PAYBANKCODE as char(20)) paybankcode, 
                                     cast(BANKCODE as char(3))bankcode, 
                                     cast(NEEDBRANCHCODE as char(1)) needBranchcode, 
                                     cast(name as char(20)) cname, 
                                     cast('ZGCJ4' as char(30)) dbcode 
                              from ZGCJ4.carddef
/

