create view YB_CJ_STATE as
select "STATE","UNTAX","INPUTTAG","NETTAG" from ZGCJ4.Member_State_Ref
/

