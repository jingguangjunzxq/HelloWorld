create trigger YBCJ_TRI_SYSPARAMS
  after update
  on YB_SYSPARAMS
  for each row
DECLARE 
v_paramname     yb_sysparams.paramname%TYPE; 
v_paramvalue     yb_sysparams.paramvalue%TYPE; 
v_paramname_old     yb_sysparams.paramname%TYPE; 
v_paramvalue_old     yb_sysparams.paramvalue%TYPE; 
v_config_name VARCHAR2(30); 
v_cj_ls_def VARCHAR2(30); 
v_sql VARCHAR2(3000); 
v_num NUMBER ; 
v_emp VARCHAR2(100); 
v_emp_1 VARCHAR2(100); 
v_emp_2 VARCHAR2(100); 
pragma autonomous_transaction; 
BEGIN 
v_paramname := :new.paramname; 
v_paramvalue := :new.paramvalue; 
v_paramname_old := :old.paramname; 
v_paramvalue_old := :old.paramvalue; 
SELECT TRIM(t.paramvalue) INTO v_config_name FROM yb_sysparams t 
where upper(trim(t.paramname)) = 'CONFIG_NAME' ; 
SELECT TRIM(t.paramvalue) INTO v_cj_ls_def FROM yb_sysparams t 
where upper(trim(t.paramname)) = 'CJ_LS_DEF' ; 
     BEGIN 
         v_sql :=  'select count(*)  from '||v_config_name||'.sys_query_detail '; 
          EXECUTE IMMEDIATE v_sql INTO v_num ; 
     EXCEPTION 
       WHEN OTHERS THEN 
         RETURN; 
     END; 
    /*更新 是否预约*/ 
    IF(TRIM(v_paramname) = 'YB_ISYB')THEN 
      if(upper(trim(v_paramvalue)) = 'T')THEN 
          v_sql :=  'UPDATE  '||v_config_name||'.sys_query_detail SET isshow = ''true'' 
                WHERE (fieldname IN(''arrange_time'',''arrange_place'', 
                ''status'',''arrange_date'')) AND funcno = 110'; 
          EXECUTE IMMEDIATE v_sql ; 
      END IF; 
      if(upper(trim(v_paramvalue)) = 'F')THEN 
        v_sql :=  'UPDATE  '||v_config_name||'.sys_query_detail SET isshow = ''false'' 
                  WHERE (fieldname IN(''arrange_time'',''arrange_place'',''arrange_date'')) AND funcno = 110'; 
        EXECUTE IMMEDIATE v_sql ; 
      END IF; 
    END IF; 
   /*酬金人员信息修改显示新酬金或者老酬金*/ 
     IF(TRIM(v_paramname) = 'CJ_SJK_Type')THEN 
          v_sql :=  'DELETE FROM '||v_config_name||'.sys_role_menu 
                WHERE NODEID= 2946'; 
          EXECUTE IMMEDIATE v_sql ; 
        v_sql :=  'DELETE FROM  '||v_config_name||'.sys_role_menu 
                where NODEID= 3126'; 
        EXECUTE IMMEDIATE v_sql ; 
      if(upper(trim(v_paramvalue)) = 'T')THEN 
        v_sql := 'insert into '||v_config_name||'.sys_role_menu(nodeid,roleid) VALUES(3126,1)'; 
        EXECUTE IMMEDIATE v_sql ; 
        v_sql := 'insert into '||v_config_name||'.sys_role_menu(nodeid,roleid) VALUES(3126,8)'; 
        EXECUTE IMMEDIATE v_sql ; 
        v_sql := 'insert into '||v_config_name||'.sys_role_menu(nodeid,roleid) VALUES(3126,9)'; 
        EXECUTE IMMEDIATE v_sql ; 
        v_sql := 'insert into '||v_config_name||'.sys_role_menu(nodeid,roleid) VALUES(3126,10)'; 
        EXECUTE IMMEDIATE v_sql ; 
        v_sql := 'insert into '||v_config_name||'.sys_role_menu(nodeid,roleid) VALUES(3126,50)'; 
        EXECUTE IMMEDIATE v_sql ; 
        v_sql := 'create or replace view yb_cj_areacode as 
        select * from '||v_cj_ls_def||'.xcodemap2 '; 
         EXECUTE IMMEDIATE v_sql ; 
        v_sql := 'create or replace view yb_cj_m_type as 
        select * from '||v_cj_ls_def||'.member_type'; 
         EXECUTE IMMEDIATE v_sql ; 
         v_sql := 'create or replace view yb_cj_state as 
        select * from '||v_cj_ls_def||'.member_state_ref'; 
         EXECUTE IMMEDIATE v_sql ; 
        v_sql := 'create or replace view yb_cj_position as 
        select * from '||v_cj_ls_def||'.xcodemap2'; 
         EXECUTE IMMEDIATE v_sql ; 
        v_sql := 'create or replace view yb_cj_kind as 
        select * from '||v_cj_ls_def||'.xcodemap2'; 
         EXECUTE IMMEDIATE v_sql ; 
         v_sql := 'create or replace view yb_cj_kind_level as 
        select * from '||v_cj_ls_def||'.xcodemap2'; 
         EXECUTE IMMEDIATE v_sql ; 
        v_sql := 'create or replace view yb_cj_entry_mode as 
        select * from '||v_cj_ls_def||'.xcodemap2'; 
         EXECUTE IMMEDIATE v_sql ; 
        v_sql := 'create or replace view yb_cj_tech_post as 
        select * from '||v_cj_ls_def||'.xcodemap2'; 
         EXECUTE IMMEDIATE v_sql ; 
        v_sql := 'create or replace view yb_cj_rank_post as 
        select * from '||v_cj_ls_def||'.xcodemap2'; 
         EXECUTE IMMEDIATE v_sql ; 
        v_sql := 'create or replace view yb_cj_procode as 
        select * from '||v_cj_ls_def||'.xcodemap2'; 
         EXECUTE IMMEDIATE v_sql ; 
        v_sql := 'create or replace view yb_cj_cercode as 
        select * from '||v_cj_ls_def||'.xcodemap2'; 
         EXECUTE IMMEDIATE v_sql ; 
         v_sql := 'create or replace view yb_cj_mz as 
        select * from '||v_cj_ls_def||'.xcodemap2'; 
         EXECUTE IMMEDIATE v_sql ; 
        v_sql := 'create or replace view yb_cj_zzmm as 
        select * from '||v_cj_ls_def||'.xcodemap2'; 
         EXECUTE IMMEDIATE v_sql ; 
        v_sql := 'create or replace view yb_cj_hyzk as 
        select * from '||v_cj_ls_def||'.xcodemap2'; 
         EXECUTE IMMEDIATE v_sql ; 
        v_sql := 'create or replace view yb_cj_xl as 
        select * from '||v_cj_ls_def||'.xcodemap2'; 
         EXECUTE IMMEDIATE v_sql ; 
        v_sql := 'create or replace view yb_cj_insurance_flag as 
        select * from '||v_cj_ls_def||'.xcodemap2'; 
         EXECUTE IMMEDIATE v_sql ; 
         v_sql := 'create or replace view yb_cj_salary_type as 
        select * from '||v_cj_ls_def||'.xcodemap2'; 
         EXECUTE IMMEDIATE v_sql ; 
         v_sql := 'create or replace view yb_cj_fundno_flag as 
        select * from '||v_cj_ls_def||'.xcodemap2'; 
         EXECUTE IMMEDIATE v_sql ; 
         v_sql := 'create or replace view yb_cj_hujilx as 
        select * from '||v_cj_ls_def||'.xcodemap2'; 
         EXECUTE IMMEDIATE v_sql ; 
      END IF; 
      if(upper(trim(v_paramvalue)) = 'F')THEN 
        v_sql := 'insert into '||v_config_name||'.sys_role_menu(nodeid,roleid) VALUES(2946,1)'; 
        EXECUTE IMMEDIATE v_sql ; 
        v_sql := 'insert into '||v_config_name||'.sys_role_menu(nodeid,roleid) VALUES(2946,8)'; 
        EXECUTE IMMEDIATE v_sql ; 
        v_sql := 'insert into '||v_config_name||'.sys_role_menu(nodeid,roleid) VALUES(2946,9)'; 
        EXECUTE IMMEDIATE v_sql ; 
        v_sql := 'insert into '||v_config_name||'.sys_role_menu(nodeid,roleid) VALUES(2946,10)'; 
        EXECUTE IMMEDIATE v_sql ; 
        v_sql := 'insert into '||v_config_name||'.sys_role_menu(nodeid,roleid) VALUES(2946,50)'; 
        EXECUTE IMMEDIATE v_sql ; 
        v_sql := 'create or replace view yb_cj_areacode as 
        select * from '||v_cj_ls_def||'.CountryArea '; 
         EXECUTE IMMEDIATE v_sql ; 
        v_sql := 'create or replace view yb_cj_state as 
        select * from '||v_cj_ls_def||'.Member_State_Ref'; 
         EXECUTE IMMEDIATE v_sql ; 
        v_sql := 'create or replace view yb_cj_dno as 
        select * from '||v_cj_ls_def||'.Departs'; 
         EXECUTE IMMEDIATE v_sql ; 
        v_sql := 'create or replace view yb_cj_depart as 
        select * from '||v_cj_ls_def||'.Departs'; 
         EXECUTE IMMEDIATE v_sql ; 
        v_sql := 'create or replace view yb_cj_tno as 
        select * from '||v_cj_ls_def||'.Teams'; 
        EXECUTE IMMEDIATE v_sql ; 
        v_sql := 'create or replace view yb_cj_team as 
        select * from '||v_cj_ls_def||'.Teams '; 
        EXECUTE IMMEDIATE v_sql ; 
        v_sql := 'create or replace view yb_cj_procode as 
        select * from '||v_cj_ls_def||'.Profession'; 
        EXECUTE IMMEDIATE v_sql ; 
      END IF; 
    END IF; 
    /*更新 是否包含数量和单价*/ 
    IF(trim(v_paramname) = 'CJ_BASEANDNUM')THEN 
        if(upper(trim(v_paramvalue)) = 'T')THEN 
        /*常用名单表 */ 
        v_sql :=  'UPDATE  '||v_config_name||'.sys_geditor_detail SET isshow = ''true'' 
        WHERE (fieldname=''unit_price'' OR fieldname=''quantity'' ) AND funcno = 2399'; 
        EXECUTE IMMEDIATE v_sql ; 
        /*常用名单表 */ 
        v_sql :=  'UPDATE  '||v_config_name||'.sys_geditor_detail SET isshow = ''true'' 
        WHERE (fieldname=''unit_price'' OR fieldname=''quantity'' ) AND funcno = 2437'; 
        EXECUTE IMMEDIATE v_sql ; 
        /*发放清单表*/ 
        v_sql :=  'UPDATE  '||v_config_name||'.sys_query_detail SET isshow = ''true'' 
        WHERE (fieldname=''unit_price'' OR fieldname=''quantity'' ) AND funcno = 2399'; 
        EXECUTE IMMEDIATE v_sql ; 
        /*历史清单导入*/ 
        v_sql :=  'UPDATE  '||v_config_name||'.sys_EditTable_detail SET hidden = ''false'' 
        WHERE (fieldname=''unit_price'' OR fieldname=''quantity'' ) AND funcno = 2411'; 
        EXECUTE IMMEDIATE v_sql ; 
        END IF; 
        if(upper(trim(v_paramvalue)) = 'F')THEN 
        /*常用名单表 */ 
        v_sql :=  'UPDATE  '||v_config_name||'.sys_geditor_detail SET isshow = ''false'' 
        WHERE (fieldname=''unit_price'' OR fieldname=''quantity'' ) AND funcno = 2399'; 
        EXECUTE IMMEDIATE v_sql ; 
        /*常用名单表*/ 
        v_sql :=  'UPDATE  '||v_config_name||'.sys_geditor_detail SET isshow = ''false'' 
        WHERE (fieldname=''unit_price'' OR fieldname=''quantity'' ) AND funcno = 2437'; 
        EXECUTE IMMEDIATE v_sql ; 
        /*发放清单表 */ 
        v_sql :=  'UPDATE '||v_config_name||'.sys_query_detail SET isshow = ''false'' 
        WHERE (fieldname=''unit_price'' OR fieldname=''quantity'' ) AND funcno = 2399'; 
        EXECUTE IMMEDIATE v_sql ; 
        /*历史清单导入*/ 
        v_sql :=  'UPDATE  '||v_config_name||'.sys_EditTable_detail SET hidden = ''true'' 
        WHERE (fieldname=''unit_price'' OR fieldname=''quantity'' ) AND funcno = 2411'; 
        EXECUTE IMMEDIATE v_sql ; 
        END IF; 
    END IF; 
/*更新 是否包含数量和单价*/ 
    IF(trim(v_paramname) = 'CJ_TAX')THEN 
        if(upper(trim(v_paramvalue)) = 'T')THEN 
        /*发放清单 */ 
        v_sql :=  'UPDATE  '||v_config_name||'.sys_geditor_detail SET isshow = ''true'' 
        WHERE (fieldname=''tax'' ) AND funcno = 2399'; 
        EXECUTE IMMEDIATE v_sql ; 
        /*常用名单表 */ 
        v_sql :=  'UPDATE  '||v_config_name||'.sys_geditor_detail SET isshow = ''true'' 
        WHERE (fieldname=''tax'' ) AND funcno = 2437'; 
        EXECUTE IMMEDIATE v_sql ; 
        /*历史清单导入*/ 
        v_sql :=  'UPDATE  '||v_config_name||'.sys_EditTable_detail SET hidden = ''false'' 
        WHERE (fieldname=''TAX'' ) AND funcno = 2411'; 
        EXECUTE IMMEDIATE v_sql ; 
        END IF; 
        if(upper(trim(v_paramvalue)) = 'F')THEN 
        /*发放清单 */ 
        v_sql :=  'UPDATE  '||v_config_name||'.sys_geditor_detail SET isshow = ''false'' 
        WHERE (fieldname=''tax'' ) AND funcno = 2399'; 
        EXECUTE IMMEDIATE v_sql ; 
        /*常用名单表*/ 
        v_sql :=  'UPDATE  '||v_config_name||'.sys_geditor_detail SET isshow = ''false'' 
        WHERE (fieldname=''tax'' ) AND funcno = 2437'; 
        EXECUTE IMMEDIATE v_sql ; 
        /*历史清单导入*/ 
        v_sql :=  'UPDATE  '||v_config_name||'.sys_EditTable_detail SET hidden = ''true'' 
        WHERE (fieldname=''TAX'' ) AND funcno = 2411'; 
        EXECUTE IMMEDIATE v_sql ; 
        END IF; 
    END IF; 
    /*更新公务卡号  东北大学;3301002519200033882;中国工商银行沈阳浑南支行*/ 
    IF(trim(v_paramname) = 'YB_GWK_INFO')THEN 
        SELECT uf_split(v_paramvalue,';',1) INTO v_emp  FROM dual; 
        v_sql :=  'UPDATE  '||v_config_name||'.sys_form_detail SET initdata = 
        '''||v_emp||''' 
        WHERE (fieldname=''gwk_pay_unit'' ) AND funcno = 3450'; 
        EXECUTE IMMEDIATE v_sql ; 
        SELECT uf_split(v_paramvalue,';',2) INTO v_emp  FROM dual; 
        v_sql :=  'UPDATE  '||v_config_name||'.sys_form_detail SET initdata = 
        '''||v_emp||''' 
        WHERE (fieldname=''gwk_pay_acnt'' ) AND funcno = 3450'; 
        EXECUTE IMMEDIATE v_sql ; 
        SELECT uf_split(v_paramvalue,';',3) INTO v_emp  FROM dual; 
        v_sql :=  'UPDATE  '||v_config_name||'.sys_form_detail SET initdata = 
        '''||v_emp||''' 
        WHERE (fieldname=''gwk_pay_bank'' ) AND funcno = 3450'; 
        EXECUTE IMMEDIATE v_sql ; 
    END IF; 
COMMIT; 
END ROLEUPDATE;
ALTER TRIGGER "YBCJ_TRI_SYSPARAMS" ENABLE
/

