create trigger SUBJ2017_TRIG1
  before insert or update of CODE,C1,C2,C3,C4,C5,CODE2,ILEVEL,C6,C7,C8,C9,C10,CODE3
  on SUBJ2017
  for each row
BEGIN

  :NEW.C1 := NVL(UF_SPLIT(:NEW.CODE, '.', 1), 0);

  :NEW.C2 := NVL(UF_SPLIT(:NEW.CODE, '.', 2), 0);

  :NEW.C3 := NVL(UF_SPLIT(:NEW.CODE, '.', 3), 0);

  :NEW.C4 := NVL(UF_SPLIT(:NEW.CODE, '.', 4), 0);

  :NEW.C5 := NVL(UF_SPLIT(:NEW.CODE, '.', 5), 0);

  :NEW.C6 := NVL(UF_SPLIT(:NEW.CODE, '.', 6), 0);

  :NEW.C7 := NVL(UF_SPLIT(:NEW.CODE, '.', 7), 0);

  :NEW.C8 := NVL(UF_SPLIT(:NEW.CODE, '.', 8), 0);

  :NEW.C9 := NVL(UF_SPLIT(:NEW.CODE, '.', 9), 0);

  :NEW.C10 := NVL(UF_SPLIT(:NEW.CODE, '.', 10), 0);

  :NEW.CODE2 := LPAD(:NEW.C1, 5, '0') || ' ' || LPAD(:NEW.C2, 4, '0')

                                      || ' ' || LPAD(:NEW.C3, 4, '0')

                                      || ' ' || LPAD(:NEW.C4, 4, '0')

                                      || ' ' || LPAD(:NEW.C5, 4, '0')

                                      || ' ' || LPAD(:NEW.C6, 4, '0')

                                      || ' ' || LPAD(:NEW.C7, 4, '0')

                                      || ' ' || LPAD(:NEW.C8, 4, '0')

                                      || ' ' || LPAD(:NEW.C9, 4, '0')

                                      || ' ' || LPAD(:NEW.C10, 4, '0');

  :NEW.CODE3 := LPAD(:NEW.C1, 11, '0') || ' ' || LPAD(:NEW.C2, 10, '0')

                                      || ' ' || LPAD(:NEW.C3, 10, '0')

                                      || ' ' || LPAD(:NEW.C4, 10, '0')

                                      || ' ' || LPAD(:NEW.C5, 10, '0')

                                      || ' ' || LPAD(:NEW.C6, 10, '0')

                                      || ' ' || LPAD(:NEW.C7, 10, '0')

                                      || ' ' || LPAD(:NEW.C8, 10, '0')

                                      || ' ' || LPAD(:NEW.C9, 10, '0')

                                      || ' ' || LPAD(:NEW.C10, 10, '0');

  IF :NEW.C10 <> 0 THEN

    :NEW.ILEVEL := 9;

  ELSIF :NEW.C9 <> 0 THEN

    :NEW.ILEVEL := 8;

  ELSIF :NEW.C8 <> 0 THEN

    :NEW.ILEVEL := 7;

  ELSIF :NEW.C7 <> 0 THEN

    :NEW.ILEVEL := 6;

  ELSIF :NEW.C6 <> 0 THEN

    :NEW.ILEVEL := 5;

  ELSIF :NEW.C5 <> 0 THEN

    :NEW.ILEVEL := 4;

  ELSIF :NEW.C4 <> 0 THEN

    :NEW.ILEVEL := 3;

  ELSIF :NEW.C3 <> 0 THEN

    :NEW.ILEVEL := 2;

  ELSIF :NEW.C2 <> 0 THEN

    :NEW.ILEVEL := 1;

  ELSE

    :NEW.ILEVEL := 0;

  END IF;

END SUBJ2017_TRIG1;


/

