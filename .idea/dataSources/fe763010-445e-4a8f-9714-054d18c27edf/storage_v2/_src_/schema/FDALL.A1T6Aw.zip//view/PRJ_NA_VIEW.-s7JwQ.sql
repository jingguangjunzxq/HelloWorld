create view PRJ_NA_VIEW as
select b.prjcode,b.subj,

nvl(a.lastyear+a.jamt1-a.damt1+a.jamt2-a.damt2+a.jamt3-a.damt3,0) qcn,

nvl(b.lastyear+b.jamt1-b.damt1+b.jamt2-b.damt2+b.jamt3-b.damt3,0) qca,

nvl(0+a.jamt4,0) jn,

nvl(0+b.jamt4,0) ja,

nvl(0+a.damt4,0) dn,

nvl(0+b.damt4,0) da,

nvl(a.lastyear+a.jamt1-a.damt1+a.jamt2-a.damt2+a.jamt3-a.damt3+a.jamt4-a.damt4,0) qmn,

nvl(b.lastyear+b.jamt1-b.damt1+b.jamt2-b.damt2+b.jamt3-b.damt3+b.jamt4-b.damt4,0) qma

from prjnumamount2012 a, prjamount2012 b

where a.prjcode(+)=b.prjcode and a.subj(+)=b.subj 

 and (b.subj='140.1.1' or b.subj like '140.1.1.%')

/

