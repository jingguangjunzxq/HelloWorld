create view YB4_SOURCE_DM as
select   cast(a.source_no as Number) source_no ,
                   cast( a.source_name as varchar2(100) ) source_name
      from ky_zjyy_new.kyyb_source_dm a
/

