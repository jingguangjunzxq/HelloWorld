create view CB_INCOME_TREE_VIEW2 as
select a.node_no,
       a.name,
       a.p_node_no,
       '' last_node,
       '' mode_name,
       '' mode_type,
       nvl(civ.plan_val, 0) plan_val,
       a.table_name,
       a.syear,
       a.depart
  from (select distinct cit.itypeb node_no,
                        x.sa_name name,
                        cit.itypea p_node_no,
                        '' last_node,
                        '' mode_name,
                        '' mode_type,
                        0 plan_val,
                        '' table_name,
                        cbid.syear,
                        cbid.depart
          from cb_income_type       cit,
               cb_budget_income_def cbid,
               xcodemap             x
         where cit.i_type = cbid.i_type
           and cit.itypeb = x.sa_code
           and cit.apply_flag='Y'
           --and x.table_name='CB_INCOME_TYPE'
           and x.field_name='ITYPEB') a, cb_income_view2 civ
 where trim(a.node_no) = civ.i_node_no(+)
 and a.depart=civ.depart(+)
 and a.syear = civ.syear(+)


/

