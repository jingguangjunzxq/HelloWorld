create view JARLTY2013 as
select to_char(to_date(syear||'/'||smonth||'/'||sday,'yyyy/mm/dd'),'yyyymmdd') as pzdate,j_amount,zph,sabstract,subj,d_amount,uni_no,stype from pzd2013
/

