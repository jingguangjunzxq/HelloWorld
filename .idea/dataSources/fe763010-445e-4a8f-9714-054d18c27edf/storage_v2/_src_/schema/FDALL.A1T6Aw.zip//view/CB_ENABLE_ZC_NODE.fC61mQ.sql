create view CB_ENABLE_ZC_NODE as
  select t_node, syear, depart
  from CB_OUTCOME_CTL t
 where act_ctl_val > 0
union (select cog2.t_node, syear, depart
        from CB_OUTCOME_CTL cot,
             CB_OUTCOME_GRP cog,
             CB_OUTCOME_GRP cog2
       where cot.act_ctl_val > 0
         and cot.t_node = cog.t_node
         and cog.groupid = cog2.groupid)


/

