create view CB_IO_FACT_COUNT as
select syear,i_node,count(*) cnt from cb_io_fact group by syear,i_node


/

