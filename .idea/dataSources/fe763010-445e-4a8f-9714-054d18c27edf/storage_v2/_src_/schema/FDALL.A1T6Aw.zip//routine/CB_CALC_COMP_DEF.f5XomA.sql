create function cb_calc_comp_def (
  v_comp_def in CHAR,
  v_sa_depart in CHAR,
  v_syear in NUMBER,
  v_report_num in CHAR
) Return char is Result char(100);
tmp_str varchar2(1000);
tmp_val varchar2(10);
start_num number;
end_num number;
pos1 number;
pos2 number;
last_pos2 number;
v_p varchar2(20);
v_value cb_bdg_base_value.value%type;
PRAGMA AUTONOMOUS_TRANSACTION;
begin
  if(length(trim(v_comp_def)) is null)then
    return '';
  end if;
  last_pos2 := 0;
  --拆解分析
  tmp_str := '';
  start_num := 1;
  end_num := 2;
  loop
    pos1 := instr(v_comp_def,'@',1,start_num);
    pos2 := instr(v_comp_def,'@',1,end_num);
    Exit when pos1 <= 0;
    tmp_val := substr(v_comp_def,pos1+1,pos2-pos1-1);
    if(last_pos2 > 0)then
      v_p := substr(v_comp_def,last_pos2+1,pos1-last_pos2-1);
    else
      v_p := substr(v_comp_def,1,pos1-1);
    end if;
    execute immediate 'select nvl(sum(cbbv.value' || v_report_num || '),0) from cb_bdg_base_def cbbd, '||
      '(select * from cb_bdg_base_value cbbv where cbbv.sa_depart = '''||v_sa_depart||''') cbbv ' ||
      'where cbbd.syear=cbbv.syear(+) and cbbd.code=cbbv.code(+) and cbbd.syear='''||v_syear||
      ''' and cbbd.code='''||tmp_val||''''
      into v_value;
    tmp_str := tmp_str||v_p||v_value;

    start_num := start_num+2;
    end_num := end_num+2;

    last_pos2 := pos2;
  end loop;

  last_pos2 := instr(v_comp_def,'@',-1,1);
  if(pos2 = 0)then
    tmp_str := trim(tmp_str) || substr(v_comp_def,last_pos2+1,length(trim(v_comp_def))-last_pos2);
  end if;
  Return tmp_str;
End;


/

