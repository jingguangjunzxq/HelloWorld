create trigger BEF_MOD_EXTER_BANK2014
  before insert or update
  on EXTER_BANK2014
  for each row
BEGIN

  IF INSERTING OR UPDATING THEN

    :NEW.SRKEY := RTRIM(:NEW.SUBJ) || '/' || :NEW.SYEAR || '/' || :NEW.SMONTH || '/' || :NEW.SDAY || '/' || :NEW.ORD;

  END IF;

END BEF_MOD_EXTER_BANK2014;


/

