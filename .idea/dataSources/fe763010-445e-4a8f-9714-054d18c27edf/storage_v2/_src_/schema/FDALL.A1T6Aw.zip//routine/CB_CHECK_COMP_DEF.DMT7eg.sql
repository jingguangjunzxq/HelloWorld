create function cb_check_comp_def (
  v_comp_def in CHAR
) Return char is Result char(100);
tmp_str varchar2(1000);
tmp_val varchar2(10);
start_num number;
end_num number;
pos1 number;
pos2 number;
v_cnt number(1);
v_tag_count number;
begin
  --如果没有公式则不检查
  if(trim(v_comp_def) is null)then
    return 'pass';
  end if;
  v_tag_count := cb_get_word_count(v_comp_def, '@');--@出现的次数
  --检查@是不是双数
  if(v_tag_count=0 or mod(v_tag_count,2)<>0)then
    return 'error:项目公式定义不合法';
  end if;
  --拆解分析
  tmp_str := '';
  start_num := 1;
  end_num := 2;
  loop
    pos1 := instr(v_comp_def,'@',1,start_num);
    pos2 := instr(v_comp_def,'@',1,end_num);
    Exit when pos1 <= 0;
    tmp_val := substr(v_comp_def,pos1+1,pos2-pos1-1);
    --检查是否存在tmp_val
    execute immediate 'select count(*) from cb_bdg_base_def where code=''' || tmp_val || ''''
      into v_cnt;
    if (v_cnt = 0) then
       tmp_str := trim(tmp_str) || tmp_val || ',';
    end if;
    start_num := start_num+2;
    end_num := end_num+2;
  end loop;
  if(trim(tmp_str) is null)then
    return 'pass';
  else
    Return '公式段 ' || tmp_str || '不存在';
  end if;
End;


/

