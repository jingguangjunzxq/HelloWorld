create function cb_checkjxdtl (
  v_proj_code in CHAR
) Return char is Result char(100);
v_count Number;
Begin
  --请自行编辑函数体
  select count(*) into v_count from cb_proj_jxdtl where proj_code = v_proj_code;
  if v_count  =  0 then
     return '请录入绩效指标';
  end if;
  Return 'pass';
End;


/

