create view YB4_PRJ_SOURCE as
select   Distinct cast(a.source_no as Number) source_no ,
                   cast( a.ky_prj_code as varchar2(100) ) source_name
      from ky_zjyy_new.kyyb_source a
/

