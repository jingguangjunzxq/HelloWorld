create view YB_CJ_TECH_POST as
select "TABLE_NAME","FIELD_NAME","FIELD_DESP","SA_CODE","SA_NAME" from ZGCJ4.xcodemap2
/

