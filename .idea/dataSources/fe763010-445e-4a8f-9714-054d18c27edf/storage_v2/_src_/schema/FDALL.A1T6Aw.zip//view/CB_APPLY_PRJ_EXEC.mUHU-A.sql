create view CB_APPLY_PRJ_EXEC as
select prj_code,ZC_G+ZR2J_G+ZR3J_G+ZFK_G exec_amt from budget_drive.x_prjsum_y2


/

