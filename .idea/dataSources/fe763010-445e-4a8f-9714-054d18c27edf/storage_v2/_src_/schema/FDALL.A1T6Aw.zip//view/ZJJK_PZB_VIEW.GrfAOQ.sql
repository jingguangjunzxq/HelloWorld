create view ZJJK_PZB_VIEW as
select (To_Char(A.SYEAR, 'FM0999')||'-'||TO_CHAR(A.SMONTH, 'FM09')||'-'||TO_CHAR(A.SDAY, 'FM09')) AS PZRQ, 
  B.J_AMOUNT AS JFJE, B.D_AMOUNT AS DFJE, B.SABSTRACT AS ZY, B.SUBJ AS KMDM,
  A.SNO AS PDH, A.STYPE2 AS PDLX, B.ORD as BH, ' ' as REMARK,
  case A.SSTATE when 1 then '是' else '否' end as SFJZ, B.UNIT_CODE as WLKH
from PZ2014 A
inner join PZD2014 B on a.UNI_NO=b.UNI_NO
where A.SMONTH<=12 and A.SYEAR>=2001 and A.SDAY<=31
with read only
/

