create view YB_CJ_MEMBER_CARD as
SELECT 
                              cast(t.state as char(50)) state, 
                              cast(t.cardflag as char(1)) cardflag, 
                              cast(t.netmodify as char(1)) netmodify, 
                              cast(a.name as char(20)) name, 
                              cast('ZGCJ4' as char(30)) dbcode 
                          FROM ZGCJ4.member_card t,ZGCJ4.carddef a 
                               WHERE t.cardflag = a.bankno
/

