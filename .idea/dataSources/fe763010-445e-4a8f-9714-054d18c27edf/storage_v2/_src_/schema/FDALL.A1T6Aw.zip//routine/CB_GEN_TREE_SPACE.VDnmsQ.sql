create function cb_gen_tree_space (
  v_code in CHAR,
  v_space_num in NUMBER
) Return varchar2 is Result varchar2(100);
Begin
 return lpad(' ',(length(trim(v_code))-2)*v_space_num,'　');
End;


/

