create function cb_gen_io_fact (
  v_syear in NUMBER,
  v_i_node in CHAR,
  v_t_node in CHAR,
  v_depart in CHAR,
  v_type in CHAR,
  v_report_num in CHAR
) Return number is result number;
v_def cb_io_fact.factb_def%type;
v_fact_name varchar2(50);
v_plan_name varchar2(50);
v_value cb_income_ctl.plan_b%type;
v_cnt number(1);
begin
  --生成字段名
  v_fact_name := 'fact'||trim(v_type)||'_def';
  v_plan_name := 'plan_'||trim(v_type)||v_report_num;
  --获取计算方式
  execute immediate 'select nvl(upper(' || v_fact_name || '),''X'') from cb_io_fact
          where syear=''' || v_syear||''' and i_node=''' || v_i_node||''' '||
          'and t_node=''' || v_t_node || ''''
    into v_def;
  --根据情况返回数据
  if trim(v_def) = 'X' then--'X'表明不可填写返回0
    v_value := 0;
  elsif (trim(v_def) = '@' or trim(v_def) = '#') then--'@'标明自行填写
    execute immediate 'select count(*) from cb_income_ctl
          where syear=''' || v_syear||''' and i_node_no=''' || v_i_node||''' '||
          'and t_node=''' || v_t_node || ''' and depart='''||v_depart||''''
    into v_cnt;
    if(v_cnt > 0)then
      execute immediate 'select ' || v_plan_name || ' from cb_income_ctl
          where syear=''' || v_syear||''' and i_node_no=''' || v_i_node||''' '||
          'and t_node=''' || v_t_node || ''' and depart='''||v_depart||''''
    into v_value;
    else
      v_value := 0;
    end if;
  else--'百分比'
    execute immediate 'select ' || v_plan_name || ' from cb_budget_income ' ||
            'where syear='''||v_syear||''' and i_node_no=''' || v_i_node || ''''
     into v_value;
     v_value := v_value * to_number(trim(v_def));
  end if;

  return v_value;
End;


/

