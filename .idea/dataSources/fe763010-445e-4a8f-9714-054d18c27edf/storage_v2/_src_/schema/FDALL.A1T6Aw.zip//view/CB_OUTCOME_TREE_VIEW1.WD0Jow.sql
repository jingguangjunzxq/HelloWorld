create view CB_OUTCOME_TREE_VIEW1 as
select a.node_no,a.name, a.p_node_no, '' last_node,'' mode_name,'' mode_type,
       nvl(cov.act_ctl_val, 0) act_ctl_val,
       a.syear,a.depart,a.table_name,a.old_allowed, '' sa_depart, '' start_year,
       nvl(ccvv.act_ctl_val_d, 0) act_ctl_val_d,
       null act_ctl_val_g, null add_allowed,
       cocv.fix_plan_a, cocv.fix_plan_b, cocv.fix_plan_c,
       cov.apply_val,apply_flag
  from (select distinct cot.ttypea node_no,
                        x.sa_name name,
                        '' p_node_no,
                        '' last_node,
                        '' mode_name,
                        '' mode_type,
                        0 plan_val,
                        0 permit_val,
                        '' req_remark,
                        '' pmt_remark,
                        cezn.syear syear,
                        cezn.depart depart,
                        '' table_name,
                        '' old_allowed,
                        cot.apply_flag
          from cb_outcome_type       cot,
               xcodemap             x,
               cb_enable_zc_node cezn
         where cot.ttypea = x.sa_code
           and cot.t_node = cezn.t_node
           --and x.table_name='CB_OUTCOME_TYPE'
           and x.field_name='TTYPEA') a, cb_outcome_view1 cov, cb_ctl_val_view1 ccvv, cb_outcome_ctl_view1 cocv
 where trim(a.node_no) = cov.node_no(+)
 and a.depart = cov.sa_depart(+)
 and a.syear = cov.syear(+)
 and a.node_no = ccvv.ttypea(+)
 and a.depart = ccvv.depart(+)
 and a.syear = ccvv.syear(+)
 and a.depart = cocv.depart(+)
 and a.syear = cocv.syear(+)
 and trim(a.node_no) = cocv.t_node(+)


/

