create trigger HT2_UPDATE_CONTRACT_STATUS
  after insert
  on HT2_CONTRACT_PAY
  for each row
declare
  v_amt ht2_contract.contract_amt%type;
  v_paid_amt_new ht2_contract.contract_amt%type;
  v_paid_amt_old ht2_contract.contract_amt%type;
  v_paid_amt ht2_contract.contract_amt%type;
  v_count number;
  PRAGMA AUTONOMOUS_TRANSACTION;
begin
  if inserting then
     v_paid_amt_new:=(:new.j_amount - :new.d_amount);
     select count(*) into v_count from ht2_contract_pay t where t.contract_no = :new.contract_no;
     if v_count >0 then
        select nvl(sum(t.j_amount - t.d_amount ), 0) into v_paid_amt_old from ht2_contract_pay t where t.contract_no = :new.contract_no;
        v_paid_amt := v_paid_amt_new+v_paid_amt_old;
        
     else
        v_paid_amt := v_paid_amt_new;
     end if;
     select nvl(max(hc.contract_amt), 0) into v_amt from ht2_contract hc where hc.contract_no = :new.contract_no;
     if v_paid_amt = v_amt then
        update ht2_contract hc set hc.contract_status = 8 where hc.contract_no = :new.contract_no;
        
        update ht2_pay_apply hpa set hpa.apply_status = 'O' where hpa.yb_req_no = :new.yb_req_no;
        commit;
    else
      update ht2_contract hc set hc.contract_status = 7 where hc.contract_no = :new.contract_no;
      update ht2_pay_apply hpa set hpa.apply_status = 'O' where hpa.yb_req_no = :new.yb_req_no;
      commit;
    end if;
    
  end if;
END;
/

