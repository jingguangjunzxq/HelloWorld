create trigger QQQQ
  after insert or update or delete
  on YB_CJ_REWARDDEF
  for each row
DECLARE
v_db VARCHAR2(30000);
D_TTPE CHAR(4);
D_CODE VARCHAR2(10);
D_DBCODE VARCHAR2(30);
/*??????*/
v_data VARCHAR2(40);
v_code VARCHAR2(10);
v_dbcode VARCHAR2(30);
v_number NUMBER;
v_i NUMBER;
v_resultstr VARCHAR2(3000);
v_z VARCHAR2(30000);/*????????*/
v_flag CHAR(1);/*????н???????*/
pragma autonomous_transaction; -- ????????????????????????????????в???????
BEGIN
SELECT decode(to_char(wm_concat(trim(code)||'-'||trim(dbcode)))||',',',','',
wm_concat(trim(code)||'-'||trim(dbcode))||',') INTO v_db FROM yb_cj_rewarddef;
IF INSERTING THEN
D_TTPE := '????';
D_CODE :=   :NEW.CODE;
D_DBCODE :=   :NEW.DBCODE;
v_db := v_db ||trim(D_CODE)||'-'||trim(D_DBCODE)||',';
ELSIF UPDATING THEN
D_TTPE := '???';
D_CODE :=   :NEW.CODE;
D_DBCODE :=   :NEW.DBCODE;
ELSE
D_TTPE := '???';
D_CODE :=   :OLD.CODE;
D_DBCODE :=   :OLD.DBCODE;
END IF;
/*?ж????*/
v_z := '';
v_number := length(v_db)- length(REPLACE(v_db,',',''));
IF(v_number >=1)THEN
/*?????*/
FOR v_i  IN 1..v_number LOOP
v_data := uf_split(v_db,',',v_i);
v_code := uf_split(v_data,'-',1);
v_dbcode := uf_split(v_data,'-',2);
IF(D_TTPE = '???')THEN
IF(trim(v_code) = trim(D_CODE))THEN
v_z := v_z||','||trim(D_DBCODE);
ELSE
v_z := v_z||','||trim(V_DBCODE);
END IF;
END IF;
IF(D_TTPE = '????')THEN
v_z := v_z||','||trim(V_DBCODE);
END IF;
IF(D_TTPE = '???')THEN
IF(trim(v_code) <> trim(D_CODE))THEN
v_z := v_z||','||trim(V_DBCODE);
END IF;
END IF;
END LOOP;
/*??????*/
if(length(replace(v_z,',',''))=0)THEN
RETURN;
END IF;
v_z := substr(trim(v_z),2)||',';
SELECT TRIM(t.paramvalue) INTO v_flag FROM yb_sysparams t
WHERE t.paramname = 'CJ_SJK_Type';
IF(v_flag ='T')THEN
ybcj_init_view_hb(v_resultstr,v_z);
ELSE
ybcj_init_view(v_resultstr,v_z);
END IF;
END IF;
IF(v_resultstr = 'error')THEN
ROLLBACK; RETURN;
END IF;
END ROLEUPDATE;

ALTER TRIGGER "QQQQ" DISABLE
/

