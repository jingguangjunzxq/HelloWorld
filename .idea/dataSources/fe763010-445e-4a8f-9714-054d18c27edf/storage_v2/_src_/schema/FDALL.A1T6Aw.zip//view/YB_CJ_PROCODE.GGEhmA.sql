create view YB_CJ_PROCODE as
select "PROCODE","PRONAME" from ZGCJ4.Profession
/

