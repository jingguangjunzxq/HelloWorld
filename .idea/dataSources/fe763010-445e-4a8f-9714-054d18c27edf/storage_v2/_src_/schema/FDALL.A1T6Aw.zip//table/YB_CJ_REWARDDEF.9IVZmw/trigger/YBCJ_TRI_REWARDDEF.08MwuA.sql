create trigger YBCJ_TRI_REWARDDEF
  after insert or update or delete
  on YB_CJ_REWARDDEF
  for each row
DECLARE 
v_db VARCHAR2(30000); 
D_TTPE CHAR(4); 
D_CODE VARCHAR2(10); 
D_DBCODE VARCHAR2(30); 
/*取出数据*/ 
v_data VARCHAR2(40); 
v_code VARCHAR2(10); 
v_dbcode VARCHAR2(30); 
v_number NUMBER; 
v_i NUMBER; 
v_resultstr VARCHAR2(3000); 
v_z VARCHAR2(30000);/*最终的字符串*/ 
v_flag CHAR(1);/*是否为薪酬合一的库*/ 
pragma autonomous_transaction; -- 指定自定义事务处理，否则不能在触发器函数中操作本表 
BEGIN 
SELECT decode(to_char(wm_concat(trim(code)||'-'||trim(dbcode)))||',',',','', 
wm_concat(trim(code)||'-'||trim(dbcode))||',') INTO v_db FROM yb_cj_rewarddef; 
IF INSERTING THEN 
D_TTPE := '新增'; 
D_CODE := :NEW.CODE; 
D_DBCODE := :NEW.DBCODE; 
v_db := v_db ||trim(D_CODE)||'-'||trim(D_DBCODE)||','; 
ELSIF UPDATING THEN 
D_TTPE := '修改'; 
D_CODE := :NEW.CODE; 
D_DBCODE := :NEW.DBCODE; 
ELSE 
D_TTPE := '删除'; 
D_CODE := :OLD.CODE; 
D_DBCODE := :OLD.DBCODE; 
END IF; 
/*判断长度*/ 
v_z := ''; 
v_number := length(v_db)- length(REPLACE(v_db,',','')); 
IF(v_number >=1)THEN 
      /*有数据*/ 
      FOR v_i  IN 1..v_number LOOP 
            v_data := uf_split(v_db,',',v_i); 
            v_code := uf_split(v_data,'-',1); 
            v_dbcode := uf_split(v_data,'-',2); 
            IF(D_TTPE = '修改')THEN 
                IF(trim(v_code) = trim(D_CODE))THEN 
                                v_z := v_z||','||trim(D_DBCODE); 
                ELSE 
                                v_z := v_z||','||trim(V_DBCODE); 
                END IF; 
            END IF; 
            IF(D_TTPE = '新增')THEN 
                      v_z := v_z||','||trim(V_DBCODE); 
            END IF; 
            IF(D_TTPE = '删除')THEN 
                IF(trim(v_code) <> trim(D_CODE))THEN 
                                v_z := v_z||','||trim(V_DBCODE); 
                END IF; 
            END IF; 
      END LOOP; 
      /*是否为空*/ 
      if(length(replace(v_z,',',''))=0)THEN 
          RETURN; 
      END IF; 
      v_z := substr(trim(v_z),2)||','; 
      IF(v_z=',')THEN 
          RETURN; 
      END IF; 
      SELECT TRIM(t.paramvalue) INTO v_flag FROM yb_sysparams t 
             WHERE t.paramname = 'CJ_SJK_Type'; 
      IF(v_flag ='T')THEN 
                 ybcj_init_view_hb(v_resultstr,v_z); 
      ELSE 
                 ybcj_init_view(v_resultstr,v_z); 
      END IF; 
END IF; 
    IF(v_resultstr <> 'pass')THEN 
                   ROLLBACK; RETURN; 
    ELSE 
                   COMMIT; 
    END IF; 
END ROLEUPDATE;
ALTER TRIGGER "YBCJ_TRI_REWARDDEF" ENABLE
/

