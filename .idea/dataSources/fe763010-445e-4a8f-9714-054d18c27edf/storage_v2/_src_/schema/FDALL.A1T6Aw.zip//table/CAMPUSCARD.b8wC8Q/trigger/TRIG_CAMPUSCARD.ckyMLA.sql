create trigger TRIG_CAMPUSCARD
  before insert or update of SNO
  on CAMPUSCARD
  for each row
BEGIN
  IF INSERTING OR UPDATING THEN
    :NEW.SNO := UPPER(:NEW.SNO);
  END IF;
END;
/

