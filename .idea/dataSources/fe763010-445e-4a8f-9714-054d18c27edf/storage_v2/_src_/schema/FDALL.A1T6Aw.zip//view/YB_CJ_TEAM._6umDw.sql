create view YB_CJ_TEAM as
select "TNO","TNAME","DNO" from ZGCJ4.Teams
/

