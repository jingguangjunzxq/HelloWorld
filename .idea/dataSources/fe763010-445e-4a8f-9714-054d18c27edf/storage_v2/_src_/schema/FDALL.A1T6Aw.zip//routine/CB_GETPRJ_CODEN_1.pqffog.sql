create function cb_getprj_coden_1 (
  v_userid in CHAR
) Return char is Result char(100);
v_prj_code char(20);
Begin
  --请自行编辑函数体
  select max(proj_code) into v_prj_code from all_proj_add where req_op_no = v_userid;
  Return v_prj_code;
End;


/

