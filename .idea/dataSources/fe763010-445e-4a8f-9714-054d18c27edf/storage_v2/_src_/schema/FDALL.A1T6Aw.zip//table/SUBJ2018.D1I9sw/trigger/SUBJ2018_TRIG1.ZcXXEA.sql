create trigger SUBJ2018_TRIG1
  before insert or update of CODE,C1,C2,C3,C4,C5,CODE2,ILEVEL,C6,C7,C8,C9,C10,CODE3
  on SUBJ2018
  for each row
BEGIN
  :NEW.ILEVEL := REGEXP_COUNT(:NEW.CODE, '\.');
  :NEW.C1 := REGEXP_SUBSTR(:NEW.CODE, '[^\.]+');
  :NEW.C2 := 0;
  :NEW.C3 := 0;
  :NEW.C4 := 0;
  :NEW.C5 := 0;
  :NEW.C6 := 0;
  :NEW.C7 := 0;
  :NEW.C8 := 0;
  :NEW.C9 := 0;
  :NEW.C10 := 0;
  IF :NEW.ILEVEL > 0 THEN
    :NEW.C2 := REGEXP_SUBSTR(:NEW.CODE, '[^\.]+', 1, 2);
    IF :NEW.ILEVEL > 1 THEN
      :NEW.C3 := REGEXP_SUBSTR(:NEW.CODE, '[^\.]+', 1, 3);
      IF :NEW.ILEVEL > 2 THEN
        :NEW.C4 := REGEXP_SUBSTR(:NEW.CODE, '[^\.]+', 1, 4);
        IF :NEW.ILEVEL > 3 THEN
          :NEW.C5 := REGEXP_SUBSTR(:NEW.CODE, '[^\.]+', 1, 5);
          IF :NEW.ILEVEL > 4 THEN
            :NEW.C6 := REGEXP_SUBSTR(:NEW.CODE, '[^\.]+', 1, 6);
            IF :NEW.ILEVEL > 5 THEN
              :NEW.C7 := REGEXP_SUBSTR(:NEW.CODE, '[^\.]+', 1, 7);
              IF :NEW.ILEVEL > 6 THEN
                :NEW.C8 := REGEXP_SUBSTR(:NEW.CODE, '[^\.]+', 1, 8);
                IF :NEW.ILEVEL > 7 THEN
                  :NEW.C9 := REGEXP_SUBSTR(:NEW.CODE, '[^\.]+', 1, 9);
                  IF :NEW.ILEVEL > 8 THEN
                    :NEW.C10 := REGEXP_SUBSTR(:NEW.CODE, '[^\.]+', 1, 10);
                  END IF;
                END IF;
              END IF;
            END IF;
          END IF;
        END IF;
      END IF;
    END IF;
  END IF;
  :NEW.CODE2 := LPAD(:NEW.C1, 5, '0') || ' ' || LPAD(:NEW.C2, 4, '0')
                                      || ' ' || LPAD(:NEW.C3, 4, '0')
                                      || ' ' || LPAD(:NEW.C4, 4, '0')
                                      || ' ' || LPAD(:NEW.C5, 4, '0')
                                      || ' ' || LPAD(:NEW.C6, 4, '0')
                                      || ' ' || LPAD(:NEW.C7, 4, '0')
                                      || ' ' || LPAD(:NEW.C8, 4, '0')
                                      || ' ' || LPAD(:NEW.C9, 4, '0')
                                      || ' ' || LPAD(:NEW.C10, 4, '0');
  :NEW.CODE3 := LPAD(:NEW.C1, 11, '0') || ' ' || CASE WHEN :NEW.C2 = :NEW.JJ_SUBJ THEN RPAD(:NEW.C2, 10, '0') ELSE LPAD(:NEW.C2, 10, '0') END
                                      || ' ' || CASE WHEN :NEW.C3 = :NEW.JJ_SUBJ THEN RPAD(:NEW.C3, 10, '0') ELSE LPAD(:NEW.C3, 10, '0') END
                                      || ' ' || CASE WHEN :NEW.C4 = :NEW.JJ_SUBJ THEN RPAD(:NEW.C4, 10, '0') ELSE LPAD(:NEW.C4, 10, '0') END
                                      || ' ' || CASE WHEN :NEW.C5 = :NEW.JJ_SUBJ THEN RPAD(:NEW.C5, 10, '0') ELSE LPAD(:NEW.C5, 10, '0') END
                                      || ' ' || CASE WHEN :NEW.C6 = :NEW.JJ_SUBJ THEN RPAD(:NEW.C6, 10, '0') ELSE LPAD(:NEW.C6, 10, '0') END
                                      || ' ' || CASE WHEN :NEW.C7 = :NEW.JJ_SUBJ THEN RPAD(:NEW.C7, 10, '0') ELSE LPAD(:NEW.C7, 10, '0') END
                                      || ' ' || CASE WHEN :NEW.C8 = :NEW.JJ_SUBJ THEN RPAD(:NEW.C8, 10, '0') ELSE LPAD(:NEW.C8, 10, '0') END
                                      || ' ' || CASE WHEN :NEW.C9 = :NEW.JJ_SUBJ THEN RPAD(:NEW.C9, 10, '0') ELSE LPAD(:NEW.C9, 10, '0') END
                                      || ' ' || CASE WHEN :NEW.C10 = :NEW.JJ_SUBJ THEN RPAD(:NEW.C10, 10, '0') ELSE LPAD(:NEW.C10, 10, '0') END;
  IF :NEW.ILEVEL = 0 THEN
    :NEW.PARENT_CODE := NULL;
  ELSIF :NEW.ILEVEL = 1 THEN
    :NEW.PARENT_CODE := :NEW.C1;
  ELSIF :NEW.ILEVEL = 2 THEN
    :NEW.PARENT_CODE := :NEW.C1 || '.' || :NEW.C2;
  ELSIF :NEW.ILEVEL = 3 THEN
    :NEW.PARENT_CODE := :NEW.C1 || '.' || :NEW.C2 || '.' || :NEW.C3;
  ELSIF :NEW.ILEVEL = 4 THEN
    :NEW.PARENT_CODE := :NEW.C1 || '.' || :NEW.C2 || '.' || :NEW.C3 || '.' || :NEW.C4;
  ELSIF :NEW.ILEVEL = 5 THEN
    :NEW.PARENT_CODE := :NEW.C1 || '.' || :NEW.C2 || '.' || :NEW.C3 || '.' || :NEW.C4 || '.' || :NEW.C5;
  ELSIF :NEW.ILEVEL = 6 THEN
    :NEW.PARENT_CODE := :NEW.C1 || '.' || :NEW.C2 || '.' || :NEW.C3 || '.' || :NEW.C4 || '.' || :NEW.C5 || '.' || :NEW.C6;
  ELSIF :NEW.ILEVEL = 7 THEN
    :NEW.PARENT_CODE := :NEW.C1 || '.' || :NEW.C2 || '.' || :NEW.C3 || '.' || :NEW.C4 || '.' || :NEW.C5 || '.' || :NEW.C6 || '.' || :NEW.C7;
  ELSIF :NEW.ILEVEL = 8 THEN
    :NEW.PARENT_CODE := :NEW.C1 || '.' || :NEW.C2 || '.' || :NEW.C3 || '.' || :NEW.C4 || '.' || :NEW.C5 || '.' || :NEW.C6 || '.' || :NEW.C7 || '.' || :NEW.C8;
  ELSIF :NEW.ILEVEL = 9 THEN
    :NEW.PARENT_CODE := :NEW.C1 || '.' || :NEW.C2 || '.' || :NEW.C3 || '.' || :NEW.C4 || '.' || :NEW.C5 || '.' || :NEW.C6 || '.' || :NEW.C7 || '.' || :NEW.C8 || '.' || :NEW.C9;
  END IF;
END;

/

