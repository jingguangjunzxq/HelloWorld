create view V_XCODEMAP as
select A."FIELD_NAME",A."SA_CODE",A."SA_NAME",A."F1_CODE",A."F2_CODE",A."F3_CODE",A."F4_CODE",A."F5_CODE",A."LEV",A."CHILDNUM",
  decode(childnum, 0, 'E', 1, 'T', 'F') leaf,
  (select sa_name from xcodemap B where B.field_name = A.field_name and B.sa_code = A.f1_code) f1_name,
  (select sa_name from xcodemap B where B.field_name = A.field_name and B.sa_code = A.f2_code) f2_name,
  (select sa_name from xcodemap B where B.field_name = A.field_name and B.sa_code = A.f3_code) f3_name,
  (select sa_name from xcodemap B where B.field_name = A.field_name and B.sa_code = A.f4_code) f4_name,
  (select sa_name from xcodemap B where B.field_name = A.field_name and B.sa_code = A.f5_code) f5_name
from
(
select A.*, 1 lev, (select count(*) from xcodemap B where B.field_name = A.field_name and B.f1_code = A.f1_code) childnum from xcodemap A where field_name = 'SA_DEPART' and sa_code = f1_code and f2_code is null
union all
select A.*, 2 lev, (select count(*) from xcodemap B where B.field_name = A.field_name and B.f2_code = A.f2_code) childnum from xcodemap A where field_name = 'SA_DEPART' and sa_code = f2_code and f3_code is null
union all
select A.*, 3 lev, (select count(*) from xcodemap B where B.field_name = A.field_name and B.f3_code = A.f3_code) childnum from xcodemap A where field_name = 'SA_DEPART' and sa_code = f3_code and f4_code is null
union all
select A.*, 4 lev, (select count(*) from xcodemap B where B.field_name = A.field_name and B.f4_code = A.f4_code) childnum from xcodemap A where field_name = 'SA_DEPART' and sa_code = f4_code and f5_code is null
) A where childnum=1
order by f1_code, f2_code, f3_code, f4_code, f5_code
/

