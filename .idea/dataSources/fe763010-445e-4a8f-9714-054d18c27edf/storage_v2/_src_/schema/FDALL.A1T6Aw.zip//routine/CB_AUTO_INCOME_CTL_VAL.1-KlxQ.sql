create function cb_auto_income_ctl_val (
  v_str in CHAR,
  v_str_y in CHAR,
  v_syear in CHAR,
  v_node_no in CHAR,
  v_depart in CHAR,
  v_minus_plan_change out CHAR,
  v_minus_plan_y out CHAR,
  v_t_node out CHAR,
  v_report_num in CHAR
) Return char is result char;
v_chk_plan cb_income_ctl.plan_b%type;
v_sum_plan cb_income_ctl.plan_b%type;
v_cnt number(1);
begin
 --初始化#号项目的值
 v_minus_plan_change := 0;
 v_minus_plan_y := 0;
 --检查有无#号项目B
 execute immediate 'select count(*) from cb_io_fact ' ||
          'where syear = :1 and i_node = :2 ' ||
          'and fact' || trim(v_str) || '_def = :3'
 into v_cnt
 using v_syear, v_node_no, '#';

 if(v_cnt = 1)then--有#号B
  --获取#号项目的节点号
  execute immediate 'select t_node from cb_io_fact ' ||
          'where syear = :1 and i_node = :2 ' ||
          'and fact' || trim(v_str) || '_def = :3'
  into v_t_node
  using v_syear, v_node_no, '#';
  --获取总金额
  execute immediate 'select plan_' || trim(v_str) || v_report_num || ' ' ||
    'from cb_budget_income cbi where cbi.syear = :1 and cbi.i_node_no = :2'
  into v_chk_plan
  using v_syear, v_node_no;
  --获取申报除了#号项目之外的总金额
  --return v_str || '<>' || v_syear || '<>' ||v_node_no || '<>' ||v_depart || '<>' ||v_t_node;
  execute immediate 'select sum(plan_' || trim(v_str) || v_report_num || ')
          from cb_income_ctl cic ' ||
          'where cic.syear = :1 and cic.i_node_no = :2 and cic.depart = :3 ' ||
          'and cic.t_node <> :4'
  into v_sum_plan
  using v_syear, v_node_no, v_depart, v_t_node;
  --如果此时已超过总金额则报错
  if(v_sum_plan > v_chk_plan)then
    if(trim(v_str) = 'b')then
      return '校控限定金额总和应为：' || v_chk_plan || ',现申报金额为：' || v_sum_plan;
    else
      v_cnt:=v_cnt;
      --return v_str || '<>' || v_syear || '<>' ||v_node_no || '<>' ||v_depart || '<>' ||v_t_node || '<>' || v_sum_plan;
      return '非校控金额总和应为：' || v_chk_plan || ',现申报金额为：' || v_sum_plan;
    end if;
  end if;
  --计算#号项目值
  v_minus_plan_change := v_chk_plan - v_sum_plan;
  select count(*) into v_cnt from cb_income_ctl
      where syear = v_syear and i_node_no = v_node_no and t_node = v_t_node and depart = v_depart;
  if(v_cnt = 0)then
    v_minus_plan_y := 0;
  else
    execute immediate 'select plan_' || trim(v_str_y) || v_report_num || ' from cb_income_ctl ' ||
        'where syear = :1 and i_node_no = :2 and t_node = :3 and depart = :4'
    into v_minus_plan_y
    using v_syear, v_node_no, v_t_node, v_depart;
  end if;
 end if;
 return 'pass';
End;


/

