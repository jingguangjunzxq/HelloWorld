create view YB_CJ_AREACODE as
select "AREACODE","AREANAME" from ZGCJ4.CountryArea
/

