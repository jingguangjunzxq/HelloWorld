create view YB_CJ_COUNTRYAREA_DEF as
select cast(areacode as char(40)) areacode, 
                                     cast(areaname as char(100)) areaname 
                              from ZGCJ4.countryarea t
/

