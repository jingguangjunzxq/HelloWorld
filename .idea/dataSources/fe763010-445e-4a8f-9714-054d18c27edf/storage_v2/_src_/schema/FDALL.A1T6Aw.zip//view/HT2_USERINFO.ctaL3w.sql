create view HT2_USERINFO as
select a.unino userid ,a.name username,a.password password,a.dept1 sysid from cwbs.userinfo a,cwbs.userrole b
where a.unino=b.unino  and b.rolecode='01' and a.dept1 is not null
/

