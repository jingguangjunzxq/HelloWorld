create view GZ_MEMBERS as
SELECT cast(t.UNI_NO AS CHAR(30)) UNI_NO,t.NAME,t.TECH_POST,t.RANK_POST,t.STATE,
trim(NAME)||TRIM(uni_no)||'DEPART' depart FROM rs_members t
/

