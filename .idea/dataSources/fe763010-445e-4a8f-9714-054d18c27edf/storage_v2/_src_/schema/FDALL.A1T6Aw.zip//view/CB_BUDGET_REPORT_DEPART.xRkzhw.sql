create view CB_BUDGET_REPORT_DEPART as
  select a,b,c,NAME,
       syear,
        PLAN_AMT,
       STATUS,
       REQ_ORDER,
       MASTAR_ORDER,
       REQ_OP_NO,
       ORD,
       req_depart_no,
       proj_code,
       SORTA,
       master_depart_no
  from (select sum(yy.plan_req)a,sum(yy.plan_zc) b,sum(yy.plan_amount) c,ps.sorta_name name,
               yy.syear,
               sum(aad.plan_amt) PLAN_AMT,
               '' status,
               '' req_order,
               '' mastar_order,
               '' req_op_no,
               ps.sorta ord,
               '' req_depart_no,
               '' proj_code,
               PS.SORTA,
               aad.master_depart_no
          from CB_PROJ_SORTA ps,all_proj_add aad,cb_practise_year yy where ps.sorta = aad.sorta and yy.proj_code = aad.proj_code
          and yy.syear  = (select paramvalue from CB_PARAMETERS t where paramname=upper('SYEAR') ) and to_number(aad.status)>=10
          group by (ps.sorta_name,yy.syear,ps.sorta,aad.master_depart_no)
        union
        select py.plan_req,py.plan_zc,py.plan_amount,'　　' || trim(ap.proj_code) || '　' || trim(ap.prj_name) name,
               py.syear,
               round((ap.plan_amt) / 10000, 2) plan_amt,
               st.sa_name,
               ap.req_order,
               ap.master_order,
               ap.req_op_no,
               trim(ap.sorta) || trim(ap.proj_code) ord,
               ap.req_depart_no req_depart_no,
               ap.proj_code,
               AP.SORTA,
               ap.master_depart_no
          from all_proj_add ap,
               (select sa_code, trim(sa_name) sa_name
                  from cb_codemap
                 where field_name = upper('PRJ_STATUS')) st,cb_practise_year py
         where ap.status = st.sa_code(+) and py.proj_code = ap.proj_code and syear  = (select paramvalue from CB_PARAMETERS t where paramname=upper('SYEAR') )and to_number(ap.status)>=10)
 union all
 select sum(yy.plan_req)a,sum(yy.plan_zc) b,sum(yy.plan_amount) c,'总支出',
               yy.syear,
               sum(aad.plan_amt) PLAN_AMT,
               '' status,
               '' req_order,
               '' mastar_order,
               '' req_op_no,
               '0',
               '' req_depart_no,
               '' proj_code,
               '',
               aad.master_depart_no
          from CB_PROJ_SORTA ps,all_proj_add aad,cb_practise_year yy where ps.sorta = aad.sorta and yy.proj_code = aad.proj_code
          and yy.syear  = (select paramvalue from CB_PARAMETERS t where paramname=upper('SYEAR') ) and to_number(aad.status)>=10
          group by (yy.syear,aad.master_depart_no)
order by ord


/

