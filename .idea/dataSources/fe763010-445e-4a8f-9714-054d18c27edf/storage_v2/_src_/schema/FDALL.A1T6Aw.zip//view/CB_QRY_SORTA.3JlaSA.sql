create view CB_QRY_SORTA as
  select '999' ord  ,'总计' proj_code,'总计' prj_name,sorta,'' d_name,'0000' req_depart_no, ''req_operator, ''manager_name,'' master_depart_no, '' status,
''plan_year, ''plan_attr_name, sum(plan_amt) plan_amt, sum(req_amt) req_amt, sum(zc_amt) zc_amt,'' tel,''prj_bg,'' prj_act,'' prj_jx,
 ''comm,''rundate,''tel2, sum(yb_amt)yb_amt, sum(yb_amt_cw)yb_amt_cw, ''comm2, sum(plan_amt_cw) plan_amt_cw, sum(req_amt_cw)req_amt_cw,
sum(zc_amt_cw)zc_amt_cw, ''comm_op,sum(plan_req)plan_req, sum(plan_zc)plan_zc, sum(plan_amount)plan_amount,sum(c_req)c_req, sum(c_zc) c_zc,
sum(c_amount)c_amount,sum(nvl(sr2_g - sr239_g - sr248_g - sr249_g, 0)) sr_amt,sum(nvl(zc_g + zr2j_g + zr3j_g + zfk_g, 0))zcc_amt
from all_proj_add ad,cb_practise_year ye,
budget_drive.x_prjsum_y2 yy,
cb_depart dd  where
ad.proj_code = ye.proj_code and yy.code(+) = ye.proj_code and dd.depart = ad.req_depart_no and status in('25','10')
group by (sorta)
union all
select ad.sorta ord,(d_name) proj_code,(d_name) prj_name,ad.sorta,d_name,req_depart_no, ''req_operator, ''manager_name,'' master_depart_no, '' status,
''plan_year, ''plan_attr_name, sum(plan_amt) plan_amt, sum(req_amt) req_amt, sum(zc_amt) zc_amt,'' tel,''prj_bg,'' prj_act,'' prj_jx,
 ''comm,''rundate,''tel2, sum(yb_amt)yb_amt, sum(yb_amt_cw)yb_amt_cw, ''comm2, sum(plan_amt_cw) plan_amt_cw, sum(req_amt_cw)req_amt_cw,
sum(zc_amt_cw)zc_amt_cw, ''comm_op,sum(plan_req)plan_req, sum(plan_zc)plan_zc, sum(plan_amount)plan_amount,sum(c_req)c_req, sum(c_zc) c_zc,
sum(c_amount)c_amount,sum(nvl(sr2_g - sr239_g - sr248_g - sr249_g, 0)) sr_amt,sum(nvl(zc_g + zr2j_g + zr3j_g + zfk_g, 0))zcc_amt
from all_proj_add ad,cb_practise_year ye,
budget_drive.x_prjsum_y2 yy,
cb_proj_sorta sa,
cb_depart dd  where
sa.sorta = ad.sorta and
ad.proj_code = ye.proj_code and yy.code(+) = ye.proj_code and dd.depart = ad.req_depart_no and status in('25', '10')
group by (ad.sorta,req_depart_no,d_name,sorta_name)
union all
select trim(ad.sorta)||'1111' ord, ad.proj_code,trim(ad.proj_code)||'   '||trim(prj_name) prj_name,ad.sorta,d_name,req_depart_no, ''req_operator, manager_name,ad.master_depart_no,  status,
''plan_year, ''plan_attr_name, sum(plan_amt) plan_amt, sum(req_amt) req_amt, sum(zc_amt) zc_amt,'' tel,''prj_bg,'' prj_act,'' prj_jx,
 ''comm,''rundate,''tel2, sum(yb_amt)yb_amt, sum(yb_amt_cw)yb_amt_cw, ''comm2, sum(plan_amt_cw) plan_amt_cw, sum(req_amt_cw)req_amt_cw,
sum(zc_amt_cw)zc_amt_cw, ''comm_op,sum(plan_req)plan_req, sum(plan_zc)plan_zc, sum(plan_amount)plan_amount,sum(c_req)c_req, sum(c_zc) c_zc,
sum(c_amount)c_amount,sum(nvl(sr2_g - sr239_g - sr248_g - sr249_g, 0)) sr_amt,sum(nvl(zc_g + zr2j_g + zr3j_g + zfk_g, 0))zcc_amt
from all_proj_add ad,cb_practise_year ye,
budget_drive.x_prjsum_y2 yy,
cb_proj_sorta sa,
cb_depart dd  where
sa.sorta = ad.sorta and
ad.proj_code = ye.proj_code and yy.code(+) = ye.proj_code and dd.depart = ad.req_depart_no and status in ('25','10')
group by (ad.sorta,req_depart_no,d_name,sorta_name,ad.proj_code,prj_name,status,manager_name,ad.master_depart_no)


/

