create view CB_OUTCOME_VIEW2 as
select cocp.syear, substr(a.ys_attr,1,2) node_no, sa_depart,
sum(cocp.act_ctl_val) act_ctl_val, sum(cocp.apply_val) apply_val
from cb_outcome_ctl_prj cocp, allproj a
where cocp.prj_code(+)=a.prj_code
and a.ys_proj = 'Y'
group by cocp.syear, substr(a.ys_attr,1,2),a.sa_depart


/

