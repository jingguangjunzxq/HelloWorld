create view YB_CJ_CERTIFICATE_DEF as
select cast(cername as char(100)) cername, 
                                     cast(cercode as char(20)) cercode 
                              from ZGCJ4.certificate t
/

