create function CB_CHECKISOPEN_r (
  v_depart in CHAR
) Return char is Result char(100);
Begin
  --请自行编辑函数体
  Return CB_CHECKISOPEN(v_depart); 
End;
/

