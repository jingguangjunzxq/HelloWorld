create view TMPZZ as
SELECT code
     FROM proj2012
    WHERE (pcode IN ('2', '3', '72', '73', '74', '96', '97', '98', '102')
           OR (pcode = '5' AND SUBSTR (CODE, 1, 2) IN ('KE', 'KR')))
          AND (sa_depart IN
                  (SELECT sa_code
                     FROM xcodemap
                    WHERE field_name = 'SA_DEPART' AND F2_CODE <> '129'
                          AND (f1_code IN ('02', '01')
                               OR f2_code IN
                                     ('0301',
                                      '1140',
                                      '1240',
                                      '1311',
                                      '1340',
                                      '2022',
                                      '6286',
                                      '2203',
                                      '2640',
                                      '901'))))
/

