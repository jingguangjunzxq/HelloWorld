create function cb_calc_allocate_new (
v_syear         CB_BUDGET_TRANS.syear%type,
v_prj_code      CB_BUDGET_TRANS.prj_code%type,
v_period_code   CB_BUDGET_TRANS_DEF.period_code%type,
v_trans_no      CB_BUDGET_TRANS_DEF.trans_no%type,
v_freeze_flag   number
)
  Return number is result number;
  v_allocate_val      CB_BUDGET_TRANS.allocate_val%type;
  v_allocate_val_old  CB_BUDGET_TRANS.allocate_val%type;
  v_exec_mode         CB_OUTCOME_TYPE.exec_mode%type;
  v_freeze_flag2       number;
begin

  v_allocate_val := 0;
  v_allocate_val_old := 0;
  v_freeze_flag2 := nvl(v_freeze_flag,0);


  select nvl(sum(allocate_val),0) into  v_allocate_val_old  from CB_BUDGET_TRANS
     where syear=v_syear and  prj_code=v_prj_code and trans_no<>v_trans_no;

  select exec_mode  into v_exec_mode from CB_OUTCOME_TYPE ct ,allproj ap
     where ap.prj_code=v_prj_code and ap.ys_attr=ct.t_node;



 if  v_freeze_flag2=0 then

              if (v_exec_mode='1' or v_exec_mode='Y') then
                select (total_permit_val - v_allocate_val_old)  into v_allocate_val
                  from cb_outcome_ctl_prj where syear=v_syear and prj_code=v_prj_code;
                return v_allocate_val;
               end if ;


              if v_exec_mode='2'   then
                if v_period_code<=6 then
                      select trunc((total_permit_val*1/2 - v_allocate_val_old),-2)  into v_allocate_val
                        from cb_outcome_ctl_prj where syear=v_syear and prj_code=v_prj_code;
                    return v_allocate_val;
                  else
                      select (total_permit_val - v_allocate_val_old)  into v_allocate_val
                         from cb_outcome_ctl_prj where syear=v_syear and prj_code=v_prj_code;
                     return v_allocate_val;
                  end if;
               end if ;


              if v_exec_mode='4'   then
                if v_period_code<=3 then
                      select trunc((total_permit_val*1/4 - v_allocate_val_old),-2)  into v_allocate_val
                        from cb_outcome_ctl_prj where syear=v_syear and prj_code=v_prj_code;
                    return v_allocate_val;
                  elsif v_period_code<=6 then
                     select trunc((total_permit_val*2/4 - v_allocate_val_old),-2)  into v_allocate_val
                         from cb_outcome_ctl_prj where syear=v_syear and prj_code=v_prj_code;
                     return v_allocate_val;
                  elsif v_period_code<=9 then
                     select trunc((total_permit_val*3/4 - v_allocate_val_old),-2)  into v_allocate_val
                         from cb_outcome_ctl_prj where syear=v_syear and prj_code=v_prj_code;
                     return v_allocate_val;
                  else
                     select (total_permit_val - v_allocate_val_old)  into v_allocate_val
                         from cb_outcome_ctl_prj where syear=v_syear and prj_code=v_prj_code;
                     return v_allocate_val;
                  end if;
               end if ;


              if v_exec_mode='C'   then
                if v_period_code=12 then
                     select (total_permit_val - v_allocate_val_old)  into v_allocate_val
                         from cb_outcome_ctl_prj where syear=v_syear and prj_code=v_prj_code;
                     return v_allocate_val;
                  else
                      select trunc((total_permit_val*v_period_code/12 - v_allocate_val_old),-2)  into v_allocate_val
                        from cb_outcome_ctl_prj where syear=v_syear and prj_code=v_prj_code;
                    return v_allocate_val;
                  end if;
               end if ;

       else

              if (v_exec_mode='1' or v_exec_mode='Y') then
                select ((total_permit_val-freeze_amt) - v_allocate_val_old)  into v_allocate_val
                  from cb_outcome_ctl_prj where syear=v_syear and prj_code=v_prj_code;
                return v_allocate_val;
               end if ;


              if v_exec_mode='2'   then
                if v_period_code<=6 then
                      select trunc(((total_permit_val-freeze_amt)*1/2 - v_allocate_val_old),-2)  into v_allocate_val
                        from cb_outcome_ctl_prj where syear=v_syear and prj_code=v_prj_code;
                    return v_allocate_val;
                  else
                      select ((total_permit_val-freeze_amt) - v_allocate_val_old)  into v_allocate_val
                         from cb_outcome_ctl_prj where syear=v_syear and prj_code=v_prj_code;
                     return v_allocate_val;
                  end if;
               end if ;

              if v_exec_mode='4'   then
                if v_period_code<=3 then
                      select trunc(((total_permit_val-freeze_amt)*1/4 - v_allocate_val_old),-2)  into v_allocate_val
                        from cb_outcome_ctl_prj where syear=v_syear and prj_code=v_prj_code;
                    return v_allocate_val;
                  elsif v_period_code<=6 then
                     select trunc(((total_permit_val-freeze_amt)*2/4 - v_allocate_val_old),-2)  into v_allocate_val
                         from cb_outcome_ctl_prj where syear=v_syear and prj_code=v_prj_code;
                     return v_allocate_val;
                  elsif v_period_code<=9 then
                     select trunc(((total_permit_val-freeze_amt)*3/4 - v_allocate_val_old),-2)  into v_allocate_val
                         from cb_outcome_ctl_prj where syear=v_syear and prj_code=v_prj_code;
                     return v_allocate_val;
                  else
                     select ((total_permit_val-freeze_amt) - v_allocate_val_old)  into v_allocate_val
                         from cb_outcome_ctl_prj where syear=v_syear and prj_code=v_prj_code;
                     return v_allocate_val;
                  end if;
               end if ;


              if v_exec_mode='C'   then
                if v_period_code=12 then
                     select ((total_permit_val-freeze_amt) - v_allocate_val_old)  into v_allocate_val
                         from cb_outcome_ctl_prj where syear=v_syear and prj_code=v_prj_code;
                     return v_allocate_val;
                  else
                      select trunc(((total_permit_val-freeze_amt)*v_period_code/12 - v_allocate_val_old),-2)  into v_allocate_val
                        from cb_outcome_ctl_prj where syear=v_syear and prj_code=v_prj_code;
                    return v_allocate_val;
                  end if;
               end if ;

        end if ;

   return v_allocate_val;

end;


/

