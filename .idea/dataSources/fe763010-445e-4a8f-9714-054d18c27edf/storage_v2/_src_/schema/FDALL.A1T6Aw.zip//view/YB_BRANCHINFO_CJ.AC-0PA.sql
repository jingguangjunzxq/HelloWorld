create view YB_BRANCHINFO_CJ as
SELECT t.branchcode branchcode ,t.bankname branchname ,t.bankname jcname FROM bankinfo  t WHERE t.branchcode IS NOT NULL  ORDER BY t.bankcode
/

