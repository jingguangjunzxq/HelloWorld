create view RS_MEMBERS as
SELECT "UNI_NO","NAME","TECH_POST","RANK_POST","STATE" FROM t_rs_members
/

