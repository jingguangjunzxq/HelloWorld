create view YB_CJ_MEMBER_STATE_REF as
select 
                                  cast(state as char(50)) state, 
                                  cast(untax as char(20)) untax, 
                                  cast(inputtag as char(6)) inputtag, 
                                  cast(nettag as char(6)) nettag, 
                                  cast('ZGCJ4' as char(30)) dbcode 
                               from ZGCJ4.member_state_ref t
/

