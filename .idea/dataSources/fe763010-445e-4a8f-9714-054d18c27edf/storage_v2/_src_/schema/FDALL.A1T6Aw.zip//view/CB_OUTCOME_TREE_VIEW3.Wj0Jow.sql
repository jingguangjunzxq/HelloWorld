create view CB_OUTCOME_TREE_VIEW3 as
select a.node_no,
       a.name,
       a.p_node_no,
       '' last_node,
       '' mode_name,
       '' mode_type,
       nvl(cov.act_ctl_val, 0) act_ctl_val,
       a.syear,
       a.depart,
       a.old_allowed,
       '' sa_depart,
       '' start_year,
       coc.act_ctl_val act_ctl_val_d,
       nvl(cb_calc_out_come_grp (a.node_no,a.depart), 0) act_ctl_val_g,
       a.add_allowed,
       coc.fix_plan_a,
       coc.fix_plan_b,
       coc.fix_plan_c,
       cov.apply_val,
       apply_flag
  from (select distinct cot.t_node node_no,
                        cot.t_name name,
                        cot.ttypeb p_node_no,
                        '' last_node,
                        '' mode_name,
                        '' mode_type,
                        0 plan_val,
                        0 permit_val,
                        '' req_remark,
                        '' pmt_remark,
                        cezn.syear syear,
                        cezn.depart depart,
                        cot.old_allowed,
                        cot.add_allowed,
                        cot.apply_flag
          from cb_outcome_type       cot,
               CB_ENABLE_ZC_NODE     cezn
         where cot.t_node=cezn.t_node) a, cb_outcome_view3 cov, cb_outcome_ctl coc
 where trim(a.node_no) = cov.node_no(+)
 and a.depart = cov.sa_depart(+)
 and a.syear = cov.syear(+)
 and a.node_no = coc.t_node(+)
 and a.depart = coc.depart(+)
 and a.syear = coc.syear(+)


/

