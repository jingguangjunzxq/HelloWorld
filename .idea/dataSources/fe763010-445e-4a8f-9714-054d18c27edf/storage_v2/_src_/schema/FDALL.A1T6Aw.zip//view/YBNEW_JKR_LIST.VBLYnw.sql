create view YBNEW_JKR_LIST as
SELECT t.no uni_no,t.name NAME FROM zgcj4.gz_member2016 t
/

