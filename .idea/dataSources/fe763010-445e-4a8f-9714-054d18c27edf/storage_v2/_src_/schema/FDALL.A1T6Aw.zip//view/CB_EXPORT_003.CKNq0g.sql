create view CB_EXPORT_003 as
select ap.prj_code,ap.name,ap.sa_depart,ap.ys_attr,ap.ys_proj,cocp.total_apply_val
from allproj ap ,cb_outcome_ctl_prj cocp
where cocp.syear=2013 and ap.prj_code=cocp.prj_code


/

