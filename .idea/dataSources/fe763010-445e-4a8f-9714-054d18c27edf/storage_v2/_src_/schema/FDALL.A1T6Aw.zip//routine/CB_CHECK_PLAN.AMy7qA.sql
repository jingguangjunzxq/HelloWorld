create function cb_check_plan (
  v_syear in CHAR,
  v_node_no in CHAR,
  v_depart in CHAR,
  v_chk_less in boolean,
  v_report_num in CHAR
) Return char is result char;
v_chk_plan_b cb_budget_income.plan_b%type;
v_chk_plan_c cb_budget_income.plan_c%type;
v_sum_plan_b cb_budget_income.plan_b%type;
v_sum_plan_c cb_budget_income.plan_c%type;
begin
 --检查是否超过总金额
 --获取总金额
 execute immediate 'select plan_b' || v_report_num || ', plan_c' || v_report_num || '
   from cb_budget_income cbi where cbi.syear = :1 and cbi.i_node_no = :2'
 into v_chk_plan_b, v_chk_plan_c
 using v_syear, v_node_no;
 --获取申报总金额
 execute immediate 'select sum(plan_b' || v_report_num || '), sum(plan_c' || v_report_num || ')
   from cb_income_ctl cic
   where cic.syear = :1
   and cic.i_node_no = :2
   and cic.depart = :3'
 into v_sum_plan_b, v_sum_plan_c
 using v_syear, v_node_no, v_depart;
 --检查金额多了还是少了
 if(v_sum_plan_b > v_chk_plan_b)then
   return '校控限定金额总和应为：' || v_chk_plan_b || ',现申报金额为：' || v_sum_plan_b;
 end if;
 if(v_sum_plan_c > v_chk_plan_c)then
   return '非校控金额总和应为：' || v_chk_plan_c || ',现申报金额为：' || v_sum_plan_c;
 end if;
 if(v_chk_less)then
   if(v_sum_plan_b < v_chk_plan_b)then
     return '校控限定金额总和应为：' || v_chk_plan_b || ',现申报金额为：' || v_sum_plan_b;
   end if;
   if(v_sum_plan_c < v_chk_plan_c)then
     return '非校控金额总和应为：' || v_chk_plan_c || ',现申报金额为：' || v_sum_plan_c;
   end if;
 end if;
 return 'pass';
End;


/

