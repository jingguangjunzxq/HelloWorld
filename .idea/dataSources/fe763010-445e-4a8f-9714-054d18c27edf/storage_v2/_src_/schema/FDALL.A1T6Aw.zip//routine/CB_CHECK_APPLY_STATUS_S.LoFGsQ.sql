create function cb_check_apply_status_s (
  op_num in NUMBER,
  v_syear in NUMBER,
  v_depart in CHAR
) Return char is result char(10);
v_cnt number(1);
v_column char(15);
v_status char(10);
Begin
  --查看有没有记录
  select count(*) into v_cnt from  cb_apply_status cas where cas.syear=v_syear and cas.depart=v_depart;
  if(v_cnt = 0)then--没有记录
    return 'pass';

  else--有记录
    --初始化检查字段名
    if(op_num = 1)then--一上
      v_column := 'first_status2';
    elsif(op_num = 2)then--二上
      v_column := 'second_status2';
    end if;
    --获取状态
    execute immediate 'select decode(cas.' || v_column || ',:1,:2,:3,:4,:5,:6) from cb_apply_status cas ' ||
      'where cas.syear=:1 and cas.depart=:72'
    into v_status
    using 'Y','fail','S','fail','N','pass', v_syear, v_depart;
    return v_status;
  end if;
End;


/

